"""Run all analyses and compare the regenerated tables to the manuscript."""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parent.parent
for name,arguments in (
 ('check_math.py',[]),
 ('reproduce_clinical.py',[]),
 ('run_simulation.py',['--replicates','700','--seed','240918']),
 ('check_manuscript.py',[]),
):
    print('\nRUN',name,*arguments,flush=True)
    subprocess.run([sys.executable,str(ROOT/'python'/name),*arguments],cwd=ROOT,check=True)
print('\nAll reproducibility checks passed.')
