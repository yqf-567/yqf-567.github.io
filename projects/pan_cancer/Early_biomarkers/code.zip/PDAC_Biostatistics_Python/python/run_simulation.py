"""Reproducible independent Python Monte Carlo study.

From project root: python python/run_simulation.py --replicates 700 --seed 240918
The seed and replication count are recorded in results/simulation_manifest.json.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
from biostat_model import SCENARIOS, METHODS, PARAMS, sample_replicate, select_rule, true_target_fpr, normal_surv
ROOT=Path(__file__).resolve().parent.parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--replicates',type=int,default=700)
    ap.add_argument('--seed',type=int,default=240918)
    args=ap.parse_args()
    if args.replicates<1: ap.error('--replicates must be >= 1')
    outdir=ROOT/'results'; outdir.mkdir(exist_ok=True)
    rows=[]
    # Stable independent stream per scenario and replication; no threading requirements.
    for sc_idx,sc in enumerate(SCENARIOS):
        print(f'{sc.label}: {args.replicates} replications',flush=True)
        for rep in range(1,args.replicates+1):
            rng=np.random.default_rng(np.random.SeedSequence([args.seed,sc_idx,rep]))
            observed=sample_replicate(rng,sc)
            for method in METHODS:
                mk,t,bnd=select_rule(observed,method)
                fpr=0.0 if mk is None else true_target_fpr(mk,t,sc)
                se=0.0 if mk is None else float(normal_surv(t,PARAMS[mk]['I']))
                rows.append(dict(scenario=sc.slug,scenario_label=sc.label,rep=rep,method=method,
                    marker=mk or 'None',threshold=t,calibration_bound=bnd,
                    true_target_fpr=fpr,true_stageI_sensitivity=se,
                    violation=int(fpr>0.1+1e-10),nontrivial=int(mk is not None)))
    repfields=list(rows[0])
    with (outdir/'simulation_replicates.csv').open('w',newline='',encoding='utf-8') as fp:
        wr=csv.DictWriter(fp,fieldnames=repfields); wr.writeheader(); wr.writerows(rows)
    sums=[]
    for sc in SCENARIOS:
        for method in METHODS:
            vals=[r for r in rows if r['scenario']==sc.slug and r['method']==method]
            sums.append(dict(scenario=sc.slug,scenario_label=sc.label,method=method,
                replications=len(vals),violation_pct=100*np.mean([r['violation'] for r in vals]),
                mean_fpr_pct=100*np.mean([r['true_target_fpr'] for r in vals]),
                mean_stageI_pct=100*np.mean([r['true_stageI_sensitivity'] for r in vals]),
                nontrivial_pct=100*np.mean([r['nontrivial'] for r in vals])))
    with (outdir/'simulation_summary.csv').open('w',newline='',encoding='utf-8') as fp:
        wr=csv.DictWriter(fp,fieldnames=list(sums[0]));wr.writeheader();wr.writerows(sums)
    import scipy
    (outdir/'simulation_manifest.json').write_text(json.dumps(dict(seed=args.seed,
         replications_per_scenario=args.replicates,versions=dict(numpy=np.__version__,scipy=scipy.__version__),
         description='New Python rerun following documented retrospective synthetic assumptions. Not the lost original Python source.'),indent=2)+'\n')
    print('Saved',len(rows),'simulation decisions and',len(sums),'summary rows')
    for r in sums:
        print(f"{r['scenario']:17s} {r['method']:17s} violations {r['violation_pct']:5.1f}%"
              f"  FPR {r['mean_fpr_pct']:5.2f}%  stage-I {r['mean_stageI_pct']:5.2f}%")
if __name__=='__main__':main()
