"""Randomized mathematical sanity checks and exact CP coverage checks.

These checks test implementations and simple identities; they do not prove
clinical applicability or novelty.
"""
import numpy as np
from scipy.stats import binom
from biostat_model import phi_gamma,mixture_envelope,archive_reweight_range,cp_upper

def main():
    rng=np.random.default_rng(1049)
    n=20000
    for i in range(n):
        p=float(rng.random());gamma=float(rng.uniform(1,8))
        q=float(phi_gamma(p,gamma))
        assert p-1e-14<=q<=1+1e-14
        h,b=rng.random(2); wa,wb=np.sort(rng.random(2)); gh,gb=rng.uniform(1,4,2)
        top=mixture_envelope(h,b,(wa,wb),gb,gh)
        brute=max((1-w)*phi_gamma(h,gh)+w*phi_gamma(b,gb)
                  for w in np.linspace(wa,wb,11))
        assert np.isclose(top,brute,atol=2e-14)
        k=int(rng.integers(0,392))
        lo,hi=archive_reweight_range(k)
        kh=np.arange(max(0,k-208),min(k,183)+1)
        full=np.concatenate([(1-w)*kh/183+w*(k-kh)/208 for w in (0.2,0.8)])
        assert np.isclose(min(full),lo) and np.isclose(max(full),hi)
    # Exact CP one-sided coverage, over a dense probability grid and n values.
    for N in (4,9,16,183,208):
        k=np.arange(N+1)
        bound=cp_upper(k,N,.05)
        for p in np.linspace(.001,.999,199):
            noncover=binom.pmf(k,N,p)[bound < p-1e-13].sum()
            assert noncover <= .05+1e-10,(N,p,noncover)
    print(f'PASS: {n} envelope and archive checks; exact-binomial checks on 995 parameter settings')
if __name__=='__main__':main()
