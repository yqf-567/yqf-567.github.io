"""Source/target spectrum risk, calibration and synthetic model.

The synthetic model is rebuilt from the prior study's documented R reference
implementation and was independently executed in Python for this revision.
It is not based on Debernardi patient-level measurements.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.stats import norm, beta as beta_dist

THRESHOLDS = np.linspace(-0.30, 3.30, 19)
MARKERS = ('LYVE1-like', 'REG1B-like')
PARAMS = {
    'LYVE1-like': {'H': (-0.55, 0.85), 'B': (0.05, 1.05), 'I': (0.70, 0.95), 'cut': 0.55},
    'REG1B-like': {'H': (-0.35, 0.95), 'B': (0.15, 1.00), 'I': (0.58, 0.95), 'cut': 0.55},
}
METHODS = ('pooled', 'spectrum_plugin', 'honest')

@dataclass(frozen=True)
class Scenario:
    slug: str
    label: str
    n_h: int
    n_b: int
    n_i: int
    w: float
    r_hi: float
    displacement: float

SCENARIOS = (
    Scenario('covered', 'Clinical-size, covered', 183, 208, 16, 0.70, 1.30, 0.0),
    Scenario('wrong_spectrum', 'Clinical-size, wrong spectrum', 183, 208, 16, 0.88, 1.90, 0.0),
    Scenario('displacement', 'Clinical-size, displaced benign', 183, 208, 16, 0.88, 1.00, 1.0),
    Scenario('expanded', 'Expanded controls, covered', 900, 900, 50, 0.70, 1.30, 0.0),
)

def phi_gamma(p, gamma=1.0):
    p = np.asarray(p, dtype=float)
    if gamma < 1 or np.any((p < 0) | (p > 1)):
        raise ValueError('p must lie in [0,1] and gamma >= 1')
    return np.minimum(gamma * p, 1 - (1 - p) / gamma)

def mixture_envelope(h, b, w_range=(0.2, 0.8), gamma_b=1.5, gamma_h=1):
    h1 = phi_gamma(h, gamma_h)
    b1 = phi_gamma(b, gamma_b)
    lo, hi = w_range
    return np.maximum((1-lo)*h1 + lo*b1, (1-hi)*h1 + hi*b1)

def cp_upper(k, n, delta):
    k = np.asarray(k, dtype=int)
    if n < 1 or not (0 < delta < 1) or np.any((k < 0) | (k > n)):
        raise ValueError('invalid binomial argument')
    out = np.ones(k.shape, dtype=float)
    interior = k < n
    if np.any(interior):
        out[interior] = beta_dist.ppf(1-delta, k[interior] + 1, n - k[interior])
    return out

def cp_two_sided(k, n, alpha=0.05):
    return ((0.0 if k == 0 else float(beta_dist.ppf(alpha/2, k, n-k+1))),
            (1.0 if k == n else float(beta_dist.ppf(1-alpha/2, k+1, n-k))))

def archive_reweight_range(k, n_h=183, n_b=208, w_range=(0.2,0.8)):
    if not (0 <= k <= n_h+n_b):
        raise ValueError('invalid pooled control positives')
    lo = max(0, k-n_b)
    hi = min(k, n_h)
    vals = [(1-w)*kh/n_h + w*(k-kh)/n_b for w in w_range for kh in (lo, hi)]
    return min(vals), max(vals)

def normal_surv(t, pars):
    return norm.sf(t, *pars)

def target_benign_tail(marker, t, r_hi=1.3):
    p = PARAMS[marker]
    t = np.asarray(t, dtype=float)
    cut = p['cut']
    p_hi = normal_surv(cut, p['B'])
    r_lo = (1-r_hi*p_hi)/(1-p_hi)
    if r_lo < 0: raise ValueError('invalid benign density tilt')
    return np.where(t >= cut,
                    r_hi*normal_surv(t, p['B']),
                    r_hi*p_hi + r_lo*(normal_surv(t, p['B'])-p_hi))

def true_target_fpr(marker, t, scenario):
    p = PARAMS[marker]
    healthy = normal_surv(t, p['H'])
    if scenario.displacement:
        benign = normal_surv(t, (p['B'][0]+scenario.displacement, p['B'][1]))
    else:
        benign = target_benign_tail(marker, t, scenario.r_hi)
    return float((1-scenario.w)*healthy + scenario.w*benign)

def sample_replicate(rng, scenario):
    return {m: {group: rng.normal(*PARAMS[m][group], size=n)
                for group,n in [('H',scenario.n_h),('B',scenario.n_b),('I',scenario.n_i)]}
            for m in MARKERS}

def select_rule(data, method, alpha=.05, beta=0.10, w_range=(0.2,0.8), gamma_b=1.5):
    if method not in METHODS: raise ValueError('unknown method')
    possibilities = []
    delta = alpha/(2*len(MARKERS)*len(THRESHOLDS))
    for im,m in enumerate(MARKERS):
        dat = data[m]
        k_h = (dat['H'][:,None] >= THRESHOLDS[None,:]).sum(axis=0)
        k_b = (dat['B'][:,None] >= THRESHOLDS[None,:]).sum(axis=0)
        h, b = k_h/len(dat['H']), k_b/len(dat['B'])
        if method == 'pooled':
            upper = (k_h+k_b)/(len(dat['H'])+len(dat['B']))
        elif method == 'spectrum_plugin':
            upper = mixture_envelope(h, b, w_range, gamma_b)
        else:
            upper = mixture_envelope(cp_upper(k_h,len(dat['H']),delta),
                                     cp_upper(k_b,len(dat['B']),delta),w_range,gamma_b)
        case_se = (dat['I'][:,None] >= THRESHOLDS[None,:]).mean(axis=0)
        for j in np.flatnonzero(upper <= beta+1e-15):
            # Larger threshold breaks sensitivity ties; first marker breaks final ties.
            possibilities.append((-float(case_se[j]), -int(j), im, m, float(THRESHOLDS[j]), float(upper[j])))
    if not possibilities:
        return None, float('inf'), 0.0
    _,_,_,mk,t,bound = min(possibilities)
    return mk,t,bound
