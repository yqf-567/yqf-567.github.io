"""Rebuild archived LYVE1/REG1B descriptive table; no patient data are imputed."""
import csv
from pathlib import Path
from biostat_model import archive_reweight_range, cp_two_sided
ROOT=Path(__file__).resolve().parent.parent

def main():
    out=[]
    for marker in ('LYVE1','REG1B'):
        source=ROOT/'data'/f'archived_{marker.lower()}_phase4.csv'
        with source.open(newline='') as f:
            tab=list(csv.DictReader(f))
        for r in tab:
            if r['method'] not in ('pooled_plugin','split_exact_hybrid'):continue
            k=round(391*float(r['observed_control_fpr']))
            i=round(16*float(r['stage_I_observed_se']))
            ii=round(86*float(r['stage_II_observed_se']))
            assert abs(k/391-float(r['observed_control_fpr']))<1e-10
            assert abs(i/16-float(r['stage_I_observed_se']))<1e-10
            assert abs(ii/86-float(r['stage_II_observed_se']))<1e-10
            lo,hi=archive_reweight_range(k)
            ci_lo,ci_hi=cp_two_sided(i,16)
            out.append(dict(marker=marker,method=r['method'],cutoff=float(r['threshold_raw_marker']),
               stageI_detected=i,stageI_total=16,stageII_detected=ii,stageII_total=86,
               control_positives=k,control_total=391,pooled_fpr=k/391,
               empirical_reweight_lower=lo,empirical_reweight_upper=hi,
               stageI_cp95_lower=ci_lo,stageI_cp95_upper=ci_hi))
    output=ROOT/'results'/'clinical_reanalysis.csv';output.parent.mkdir(exist_ok=True)
    with output.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(out[0])); writer.writeheader();writer.writerows(out)
    for x in out:
        print(f"{x['marker']:5s} {x['method']:18s}  Stage I {x['stageI_detected']}/16"
              f"  control {x['control_positives']}/391  hypothetical empirical range"
              f" {100*x['empirical_reweight_lower']:.2f}-{100*x['empirical_reweight_upper']:.2f}%")
    print('Wrote',output,'(archived aggregate analysis; not independent patient-level validation)')
if __name__=='__main__': main()
