"""Verify reported manuscript table values against this Python rerun's CSVs."""
import csv
from pathlib import Path
from biostat_model import SCENARIOS, METHODS
ROOT=Path(__file__).resolve().parent.parent
TEX=(ROOT/'manuscript'/'PDAC_Biostatistics_Revised.tex').read_text()
LABELS={'covered':'Clinical-size, covered','wrong_spectrum':'Wrong spectrum/ratio',
 'displacement':'Unmodeled displacement','expanded':'Expanded controls, covered'}
METHOD_NAMES={'pooled':'Pooled','spectrum_plugin':'Spectrum plug-in','honest':'Simultaneous'}

def main():
    with (ROOT/'results'/'simulation_summary.csv').open(newline='') as f:
        rows=list(csv.DictReader(f))
    prev=None
    for row in rows:
        scen=row['scenario'];mn=METHOD_NAMES[row['method']]
        prefix=LABELS[scen] if scen!=prev else ''
        expected=(f"{prefix} & {mn} & {float(row['violation_pct']):.1f} & "
                  f"{float(row['mean_fpr_pct']):.2f} & {float(row['mean_stageI_pct']):.2f}\\\\")
        assert expected in TEX, f'Not matched simulation table: {expected}'
        prev=scen
    with (ROOT/'results'/'clinical_reanalysis.csv').open(newline='') as f:
        rows=list(csv.DictReader(f))
    for r in rows:
        short='Pooled' if r['method']=='pooled_plugin' else 'Conservative'
        expected=(f"{r['marker']} & {short} & {float(r['cutoff']):.2f} & "
             f"{r['stageI_detected']}/16 & {r['stageII_detected']}/86 & "
             f"{r['control_positives']}/391 & "
             f"{100*float(r['empirical_reweight_lower']):.2f}--{100*float(r['empirical_reweight_upper']):.2f}\\\\")
        assert expected in TEX, f'Not matched clinical table: {expected}'
    assert r'\documentclass[12pt]' in TEX
    assert r'\textit{' not in TEX and r'\texttt{' not in TEX
    assert TEX.count(r'\subsection')==2
    print(f'PASS: 12 simulation rows and {len(rows)} clinical rows match the manuscript; typography checks passed')
if __name__=='__main__':main()
