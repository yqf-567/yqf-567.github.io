# Reliability of early pancreatic cancer biomarkers — Python reproducibility package

## Manuscript

`manuscript/PDAC_Biostatistics_Revised.tex` (12-point article), with its own separate `manuscript/references.bib`. The paper reports a spectrum-sensitivity analysis, finite-sample calibration theorem, fixed-seed Monte Carlo evaluation and a *retrospective archive-only* LYVE1/REG1B illustration.

## Reproduce the results

From the extracted ZIP root, use a recent Python 3 version:

```bash
python -m pip install -r requirements.txt
python python/run_all.py
```

Or run individual steps:

```bash
python python/check_math.py
python python/reproduce_clinical.py
python python/run_simulation.py --replicates 700 --seed 240918
python python/check_manuscript.py
```

The runner generates `results/clinical_reanalysis.csv`, `results/simulation_replicates.csv`, `results/simulation_summary.csv`, and `results/simulation_manifest.json`. The shipped copies are output from the executed Python run. The full 2,800 scenario replications produce 8,400 rows (three calibration rules per replicate). Simulation tables in the manuscript match this newly executed run.

## Provenance and scientific qualifications

- **Important source distinction:** The Python source from the *earlier* study was not retained. For this revision, the simulation was reconstructed in Python from the saved, documented model and its R translation, then actually re-executed in Python. This is a reproducible new run, **not** recovery of the old Python source or an exact replay of its old random stream. Values changed slightly from the preceding manuscript; the revised paper reports the new outputs.
- The clinical inputs `data/archived_lyve1_phase4.csv` and `data/archived_reg1b_phase4.csv` are *existing Phase IV aggregate R outputs* preserved unchanged. The program recomputes in-sample positive counts and empirical reweighting bounds. Neither the Python code nor the manuscript claims to have examined the raw 590-patient workbook. The patient-level original is referenced in Debernardi et al. 2020.
- Assumed target benign shares `w in [0.2,0.8]`, benign density-ratio allowance `Gamma_B = 1.5` and FPR cap `beta = 0.10` are **methodological scenarios** and not screening standards or observed PDAC population quantities.
- The archived conservative clinical thresholds were historically calibrated under different assumptions (`Gamma_B=2` plus score displacement), and are not the Monte Carlo thresholds.
- The methods guarantee only conditional false-positive calibration if the shift assumptions are correct. They do not guarantee target sensitivity or representatively validate screening.
- Monte Carlo normal scores are synthetic and are **not** modeled using actual LYVE1/REG1B patient-level scores.
- This manuscript and associated source are fully AI-generated and may contain errors. Independent scientific, mathematical, and clinical review is essential.

## File guide

- `python/biostat_model.py`: model, exact confidence bounds, target risk, selection methods.
- `python/run_simulation.py`: executed 4-scenario Monte Carlo generator.
- `python/reproduce_clinical.py`: retrospective clinical table from archived aggregates.
- `python/check_math.py`: randomized algebra and exact one-sided binomial checks.
- `python/check_manuscript.py`: confirms reported table values match the executed CSV outputs and typography restrictions.
- `python/run_all.py`: one-command reproducibility suite.
- `data/*.csv`: unmodified archived inputs.
- `results/*.csv`: the executed Python outputs included with the package.
- `manuscript/*.tex` and `manuscript/*.bib`: source manuscript and citations for standalone editing.

## Document layout check

The LaTeX source was tested with `pdflatex -draftmode` and `bibtex8`, including the reference list; no PDF was produced. There were no unresolved citations and no reported overfull boxes in the final draft-mode log. `xurl`, restrained column spacing, and a responsive table layout are included to prevent URLs and tables from exceeding the page width at 12 points.
