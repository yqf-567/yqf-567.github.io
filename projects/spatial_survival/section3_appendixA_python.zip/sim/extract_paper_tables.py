"""Extract the 180 Appendix A reference rows from the supplied PDF with pdftotext.

Use once to build the bundled published_appendix_A.csv. Poppler's pdftotext
must be installed. This script extracts *published* values; it does not use
those values in fitting or create synthetic Monte Carlo replicates.
"""
import argparse
from pathlib import Path
import re
import subprocess

import pandas as pd


SETTING = re.compile(r'n\s*(1200|240|120)\s*tau\s*(0\.5|0\.9)\s*c\s*(20|40)')
PARAM = re.compile(r'(α[123]|β[123]|σ[123]|τ[123]|ρ12|ρ23|ρ13;2)')
NUM = re.compile(r'[+\-−]?\d+(?:\.\d+)?')
P_MAP = {"α":"alpha", "β":"beta", "σ":"sigma", "τ":"tau", "ρ":"rho"}


def extract(pdf):
    t = subprocess.check_output(["pdftotext","-f","9","-l","12","-layout",str(pdf),"-"],text=True)
    rows=[]
    current=None
    for raw_line in t.splitlines():
        line = raw_line.replace("−", "-")
        match = SETTING.search(line)
        if match:
            n,tau,c = match.groups()
            current=(int(n),float(tau),int(c)/100)
            line = line[match.end():]
        param_match = PARAM.search(line)
        if not current or not param_match:
            continue
        token = param_match.group(1)
        # Make sure there are exactly 5 numbers after parameter name.
        vals = NUM.findall(line[param_match.end():])
        if len(vals) < 5:
            continue
        name = token.replace("ρ13;2", "rho13_2")
        if name == token:
            name = P_MAP[token[0]]+token[1:]
        tru,bias,sd,se,coverage = [float(z) for z in vals[:5]]
        n,tau,censor=current
        rows.append(dict(setting=f"n{n}_tau{tau}_c{int(censor*100)}",
                         n=n,tau=tau,censor=censor,parameter=name,
                         published_true=tru,published_bias=bias,
                         published_empirical_sd=sd,
                         published_mt_se=se,published_coverage=coverage/100))
    if len(rows)!=180:
        raise ValueError(f"Expected 12 scenarios x 15 parameters = 180 rows; found {len(rows)}")
    if len(set((r["setting"],r["parameter"]) for r in rows))!=180:
        raise ValueError("Duplicate parameter rows in table extraction")
    return pd.DataFrame(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("pdf",type=Path)
    ap.add_argument("--out",type=Path,default=Path("published_appendix_A.csv"))
    a=ap.parse_args()
    df=extract(a.pdf)
    df.to_csv(a.out,index=False)
    print(f"Wrote {len(df)} verified reference rows to {a.out}")


if __name__=="__main__":
    main()
