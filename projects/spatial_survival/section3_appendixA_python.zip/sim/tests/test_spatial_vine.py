import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import numpy as np
from scipy.stats import multivariate_normal, norm

from simulate import simulate, true_parameters
from spatial_vine import (Block, block_joint_loglik, block_margin_loglik,
                          corr_matrix, gaussian_observed_loglik, upper_orthant)


class GaussianVineTests(unittest.TestCase):
    def test_vine_partial_correlations(self):
        r12,r23,partial=.55,.45,-.35
        R=corr_matrix([r12,r23,partial])
        self.assertTrue(np.linalg.eigvalsh(R).min()>0)
        implied=(R[0,2]-r12*r23)/np.sqrt((1-r12*r12)*(1-r23*r23))
        self.assertAlmostEqual(implied,partial,places=12)

    def test_upper_orthant_independence(self):
        l=np.array([-.8,.2,1.1])
        ref=np.prod(norm.sf(l))
        self.assertAlmostEqual(upper_orthant(l,np.zeros(3),np.eye(3)),ref,places=9)

    def test_upper_orthant_correlated(self):
        C=np.array([[1,.4,-.25],[.4,1,.15],[-.25,.15,1]])
        lo=np.array([-.3,.25,.5])
        true=multivariate_normal.cdf(-lo,mean=np.zeros(3),cov=C,
                                     maxpts=300000,abseps=1e-9, rng=np.random.default_rng(2))
        self.assertLess(abs(upper_orthant(lo,np.zeros(3),C,order=35)-true),1e-4)

    def test_no_censoring_normal_density(self):
        mu=np.array([.3,-.4,.7])
        C=np.array([[1.2,.1,.0],[.1,.9,.2],[0,.2,.8]])
        t=np.exp([.4,-.3,1.1])
        ll=gaussian_observed_loglik(mu,C,t,np.ones(3,dtype=bool),
                                    np.ones(3,dtype=bool))
        self.assertAlmostEqual(ll, multivariate_normal.logpdf(np.log(t),mu,C),places=10)

    def test_unentered_contributes_nothing(self):
        mu=np.array([.3,-.4,.7])
        cov=np.eye(3)
        t=np.array([2.0,np.nan,np.nan])
        ll=gaussian_observed_loglik(mu,cov,t,np.array([False,False,False]),
                                    np.array([True,False,False]))
        self.assertAlmostEqual(ll,norm.logsf(np.log(2)-.3),places=10)

    def test_generator_risk_sets(self):
        blocks, info=simulate(120,.5,.4,seed=1234,pilot_size=1000)
        self.assertEqual(info["entered_gap1"],120)
        for b in blocks:
            self.assertTrue(np.all(b.entered[:,2]<=b.entered[:,1]))
            self.assertTrue(np.all(b.entered[:,1]<=b.event[:,0]))
            self.assertTrue(np.all(b.entered[:,2]<=b.event[:,1]))
            self.assertTrue(np.all(np.isnan(b.time[~b.entered])))

    def test_exact_two_stage_normal_case(self):
        x=np.array([-.2,.4])
        g=np.array([[2.,3.,4.],[1.,5.,2.]])
        b=Block(x,np.array([[0.,0.],[.31,0.]]),g,
                np.ones((2,3),bool),np.ones((2,3),bool),.45)
        par=np.array([0,.45,np.log(.85),np.log(.5),
                      0,-.35,np.log(.85),np.log(.5),
                      0,.65,np.log(.85),np.log(.5),
                      .55,.45,-.35])
        self.assertTrue(np.isfinite(block_joint_loglik(b,par)))
        for j in range(3):
            self.assertTrue(np.isfinite(block_margin_loglik(b,par[4*j:4*j+4],j)))


if __name__=="__main__": unittest.main()
