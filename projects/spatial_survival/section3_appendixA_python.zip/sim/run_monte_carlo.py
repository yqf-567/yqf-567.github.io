"""Command-line Monte Carlo runner. Run `python run_monte_carlo.py --help`."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from spatial_vine import PARAMETER_NAMES, fit_two_stage, murphy_topel, natural_parameters
from simulate import simulate, true_parameters


SCENARIOS = [(n, tau, censor) for n in (120, 240, 1200)
             for tau in (.5, .9) for censor in (.2, .4)]


def run_one(n, tau, censor, rep, seed, quad_order=20, maxiter=160, calculate_mt=True):
    blocks, info = simulate(n, tau, censor, seed)
    gamma, opt = fit_two_stage(blocks, order=quad_order, maxiter=maxiter)
    est = natural_parameters(gamma)
    if calculate_mt:
        se, _, diagnostics = murphy_topel(blocks, gamma, order=quad_order)
        info["MT_A_condition"] = diagnostics["A_condition"]
    else:
        se = np.full(15, np.nan)
        info["MT_A_condition"] = np.nan
    row = dict(n=n, tau=tau, censor=censor, replicate=rep, seed=seed,
               stages_converged=sum(o["success"] for o in opt),
               all_converged=all(o["success"] for o in opt), **info)
    for name, e, s in zip(PARAMETER_NAMES, est, se):
        row[name] = float(e)
        row[name+"_MTSE"] = float(s)
    return row


def summarize(raw):
    out = []
    for (n, tau, censor), sub in raw.groupby(["n", "tau", "censor"], sort=True):
        truth = true_parameters(tau)
        for j, name in enumerate(PARAMETER_NAMES):
            values = sub[name].to_numpy(float)
            ses = sub[name+"_MTSE"].to_numpy(float)
            valid = np.isfinite(values)
            with_se = valid & np.isfinite(ses) & (ses > 0)
            covered = (np.abs(values[with_se]-truth[j]) <= 1.96*ses[with_se])
            out.append(dict(setting=f"n{n}_tau{tau}_c{int(censor*100)}",
                            n=n, tau=tau, censor=censor, parameter=name,
                            true=truth[j], bias=float(np.nanmean(values[valid]-truth[j]))
                            if valid.any() else np.nan,
                            empirical_sd=float(np.std(values[valid], ddof=1))
                            if valid.sum() > 1 else np.nan,
                            mean_mt_se=float(np.mean(ses[with_se])) if with_se.any() else np.nan,
                            coverage=float(np.mean(covered)) if covered.size else np.nan,
                            n_estimates=int(valid.sum()), n_se=int(with_se.sum())))
    return pd.DataFrame(out)


def main():
    p = argparse.ArgumentParser(description="Section 3 / Appendix A Monte Carlo")
    p.add_argument("--scenario", choices=["all"] + [
        f"n{n}_tau{t}_c{int(c*100)}" for n,t,c in SCENARIOS], default="all")
    p.add_argument("--replicates", type=int, default=500,
                   help="number of MC samples per scenario; paper does not specify original count")
    p.add_argument("--seed", type=int, default=20261116)
    p.add_argument("--quad-order", type=int, default=20)
    p.add_argument("--maxiter", type=int, default=160)
    p.add_argument("--skip-mt", action="store_true", help="fast point-estimate-only diagnostic")
    p.add_argument("--out", type=Path, default=Path("results"))
    p.add_argument("--resume",action="store_true",help="continue this scenario/seed configuration from saved rows")
    p.add_argument("--overwrite",action="store_true",help="replace any saved replicate estimates")
    a = p.parse_args()
    if a.replicates < 1:
        p.error("--replicates must be >= 1")
    a.out.mkdir(parents=True, exist_ok=True)
    checkpoint = a.out/"replicate_estimates.csv"
    if a.resume and a.overwrite:
        p.error("Choose only one of --resume and --overwrite")
    if checkpoint.exists() and not(a.resume or a.overwrite):
        p.error("Output already has a run. Choose --resume or a new --out directory")
    rng = np.random.SeedSequence(a.seed)
    cases = [(n,t,c) for n,t,c in SCENARIOS if a.scenario in (
        "all", f"n{n}_tau{t}_c{int(c*100)}")]
    # A fresh entropy-derived child seed per replicate, so independent samples.
    all_children = rng.spawn(len(cases)*a.replicates)
    rows = pd.read_csv(checkpoint).to_dict("records") if (a.resume and checkpoint.exists()) else []
    completed = {(int(r["n"]),round(float(r["tau"]),6),round(float(r["censor"]),6),
                  int(r["replicate"])):int(r["seed"]) for r in rows}
    t0 = time.time()
    for i, (n, tau, censor) in enumerate(cases):
        for rep in range(a.replicates):
            ss = all_children[i*a.replicates+rep]
            seed = int(ss.generate_state(1)[0])
            key=(n,round(tau,6),round(censor,6),rep+1)
            if key in completed:
                if completed[key]!=seed:
                    raise RuntimeError(f"Cannot resume: saved seed mismatch for {key}")
                print(f"Skipping previously completed {key}",flush=True)
                continue
            print(f"Running n={n} tau={tau} censor={censor} rep={rep+1}/{a.replicates}",flush=True)
            row = run_one(n,tau,censor,rep+1,seed,a.quad_order,a.maxiter,not a.skip_mt)
            rows.append(row)
            # Checkpoint after each replicate: no lost progress on interruption.
            pd.DataFrame(rows).to_csv(checkpoint, index=False)
            summarize(pd.DataFrame(rows)).to_csv(a.out/"appendix_A_results.csv", index=False)
    with (a.out/"run_metadata.json").open("w") as f:
        json.dump({"seed": a.seed,"replicates":a.replicates, "scenarios":cases,
                   "quad_order":a.quad_order,"mt_enabled":not a.skip_mt,
                   "elapsed_seconds":time.time()-t0,
                   "censoring_law":"C~Exponential(rate), calibrated for P(T3>C)",
                   "parameterization":"alpha,beta,log(sigma),log(tau),vine partial correlations"},f,indent=2)
    print(f"Saved {len(rows)} replicate fits in {a.out.resolve()}")


if __name__ == "__main__":
    main()
