# Execution and verification record

Verified in Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3.

- 7/7 unit tests passed (`python -m unittest discover -s tests -v`).
- `verification_runs/n120_single/`: one actual `n=120, tau=0.5,
  censor=0.2` fit, with all 15 MT SEs computed, not imputed.
- `verification_runs/n1200_single/`: one actual `n=1200, tau=0.5,
  censor=0.2` fit and its 15 MT SEs.
- `verification_runs/grid_two_replicates/`: full 12-scenario grid, two
  independent replicates per setting, actual MT SEs and Appendix A reporting.
- `published_appendix_A.csv`: 180 reference parameter rows extracted
  separately from the manuscript. The reference file is never used in model
  fitting, only in post-run comparison.

The two-replicate grid is an **integration test**, not an adequately powered
Monte Carlo study: empirical SDs and coverage percentages from two
replicates are too imprecise for scientific interpretation. Execute the full
user-selected number of independent replicates to estimate bias, empirical
SD, and 95% coverage.

The paper's original random seeds, censoring distribution/calibration,
replication count and optimization settings are not stated; see README.md.
