"""Simulation generator for section 3 and Appendix A."""
from __future__ import annotations

from functools import lru_cache
import numpy as np
from scipy.optimize import brentq

from spatial_vine import Block, corr_matrix


SITES = np.array([[0., 0.], [.31, 0.], [.10, .35]])
SPATIAL_RANGE = .45
ALPHA = np.zeros(3)
BETA = np.array([.45, -.35, .65])
SIGMA = np.full(3, .85)
RHO = np.array([.55, .45, -.35])


def latent_sample(n, tau, rng):
    """Generate complete gaps, X, w under the declared block/site design."""
    if n % 3:
        raise ValueError("Paper's complete three-site design requires n % 3 == 0")
    n_blocks = n // 3
    x = rng.normal(size=(n_blocks, 3))
    dist = SITES[:, None, :] - SITES[None, :, :]
    k = np.exp(-np.linalg.norm(dist, axis=-1)/SPATIAL_RANGE)
    # w independently distributed across margins, spatially correlated within.
    w = rng.normal(size=(n_blocks, 3, 3))
    w = np.einsum('bkj,ik->bij', w, tau*np.linalg.cholesky(k))
    z = rng.normal(size=(n_blocks, 3, 3)) @ np.linalg.cholesky(corr_matrix(RHO)).T
    log_gaps = ALPHA + BETA*x[:, :, None] + w + SIGMA*z
    return x, np.exp(log_gaps)


@lru_cache(maxsize=30)
def censoring_rate(tau, target, pilot_size=30000, calibration_seed=23081):
    """Exponential admin censoring rate calibrated for P(T3>C)=target.

    The paper does not specify its censoring-time law or calibration target.
    This implementation explicitly defines 'censoring proportion' as the
    expected proportion with fewer than three completed gaps. It uses a
    separate, fixed-seed pilot independent of the MC replicates.
    """
    if not 0 < target < 1:
        raise ValueError("target must be in (0, 1)")
    pilot_n = 3*int(np.ceil(pilot_size/3))
    _, gap = latent_sample(pilot_n, tau, np.random.default_rng(calibration_seed))
    t3 = gap.sum(axis=-1).ravel()
    rate = brentq(lambda r: np.mean(np.exp(-r*t3)) - (1-target),
                  1e-9, 100., xtol=1e-11)
    return float(rate)


def simulate(n, tau, target_censoring, seed, pilot_size=30000):
    rng = np.random.default_rng(seed)
    x, gaps = latent_sample(n, tau, rng)
    rate = censoring_rate(float(tau), float(target_censoring), pilot_size)
    c = rng.exponential(scale=1/rate, size=x.shape)
    prior_elapsed = np.concatenate([
        np.zeros((*x.shape, 1)), np.cumsum(gaps, axis=-1)[:, :, :2]
    ], axis=-1)
    entered = prior_elapsed < c[:, :, None]
    remaining = np.maximum(c[:, :, None]-prior_elapsed, 0)
    event = entered & (gaps <= remaining)
    time = np.where(entered, np.minimum(gaps, remaining), np.nan)
    blocks = [Block(x=x[b], coordinates=SITES.copy(),
                    time=time[b], event=event[b], entered=entered[b],
                    spatial_range=SPATIAL_RANGE) for b in range(n//3)]
    actual_not_3 = 1 - np.mean(event[:, :, 2])
    return blocks, {"admin_rate": rate,
                    "realized_incomplete_third_event": float(actual_not_3),
                    "entered_gap1": int(entered[:, :, 0].sum()),
                    "entered_gap2": int(entered[:, :, 1].sum()),
                    "entered_gap3": int(entered[:, :, 2].sum()),
                    "completed_gap1": int(event[:, :, 0].sum()),
                    "completed_gap2": int(event[:, :, 1].sum()),
                    "completed_gap3": int(event[:, :, 2].sum())}


def true_parameters(tau):
    result = []
    for j in range(3):
        result.extend([ALPHA[j], BETA[j], SIGMA[j], tau])
    return np.array(result + list(RHO), dtype=float)
