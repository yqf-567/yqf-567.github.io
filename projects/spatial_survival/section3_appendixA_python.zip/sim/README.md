# Reproducing Section 3 and Appendix A (Python)

This is a runnable, independent reconstruction of Section 3 and Appendix A of
Yuqing Fan, *Modelling Multivariate Spatial-Survival Data using D-Vine Copula*
(PDF supplied with this request). It simulates three sequential gap times at
three spatial sites per independent block, fits the two-stage estimator,
computes cluster Murphy--Topel standard errors, and constructs the 15-parameter
simulation tables for all 12 scenarios. No code or outcome is trained on, or
back-calculated from, the published estimates.

## Quick start

Requires Python 3.10+.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v

# One fast end-to-end replicate WITH Murphy--Topel SEs:
python run_monte_carlo.py --scenario n120_tau0.5_c20 --replicates 1 --out results/quick
python compare_published.py --results results/quick/appendix_A_results.csv \
    --out results/quick/comparison_with_paper.csv

# All 12 settings, requested Monte Carlo replication (very computationally expensive):
python run_monte_carlo.py --scenario all --replicates 500 --seed 20261116 \
    --out results/full
python compare_published.py --results results/full/appendix_A_results.csv \
    --out results/full/comparison_with_paper.csv
```

Running the large, full grid can require many hours or longer on one CPU. The
paper never declares its original replication counts; **500 is a configurable
choice, not a recovered original setting**. To continue an interrupted run
with identical options, append `--resume`. Use `--overwrite` explicitly to
start over at an existing output path. A CSV checkpoint is written after each
replicate. For a fast point-estimate-only run, use `--skip-mt` (no SE/coverage).

Available scenarios: `n120_tau0.5_c20`, `n120_tau0.5_c40`,
`n120_tau0.9_c20`, `n120_tau0.9_c40` and the analogous combinations for
`n240` and `n1200`. Use `--scenario all` to include every scenario.

## Model mapping

| Paper | Implementation |
| --- | --- |
| Eq. (1) | `log G_j = alpha_j + beta_j X + w_j + sigma_j eps_j` |
| Eq. (2) | Block-specific Gaussian spatial effects, `K_ik = exp(-distance/0.45)` |
| Eq. (3) | Three Gaussian vine partial correlations, converted to a 3x3 residual correlation matrix |
| Eq. (4) | Calendar-time censoring with sequential gap entry and remaining follow-up |
| Eq. (5) | Marginal censored spatial Gaussian log-gap likelihood for entered gaps |
| Eq. (8) | Full observed-data Gaussian block likelihood; stage 1 is fixed while optimizing vine correlations |
| Eq. (9) | Cross-stage stacked-score sandwich, independent blocks as clusters |

The Gaussian model permits integrating the spatial frailties **analytically**:
the vector of all latent log gaps in a block is multivariate normal with

`Cov(Y_ij, Y_kl) = 1(i=k) sigma_j sigma_l R[j,l] + 1(j=l) tau_j^2 K[i,k]`.

For the observed data, completed gaps contribute a multivariate normal density;
censored *entered* gaps contribute a conditional Gaussian upper-orthant
probability. Gaps not entered before administrative study end are integrated
out and **do not** contribute a censoring time of zero. Upper-orthant
probabilities are evaluated by fixed-order Gauss-Legendre quadrature, up to
dimension 3. Jacobians `-log G` are constant in the parameters and are omitted
from optimization; this does not change estimates or MT derivatives.

The latent design follows the text exactly where specified:

- Three sites at `(0,0)`, `(0.31,0)`, `(0.10,0.35)`; range `phi=0.45`.
- `X ~ Normal(0,1)`; intercepts `(0,0,0)`; slopes `(0.45,-0.35,0.65)`.
- All residual SDs `0.85`, all spatial SDs `tau=0.5` or `tau=0.9`.
- Vine partial correlations `rho12=0.55`, `rho23=0.45`, `rho13;2=-0.35`.
- Sample sizes `120, 240, 1200` and target censoring `20%, 40%`.

## Essential choices NOT disclosed by the PDF

The manuscript provides numerical results but **does not specify** its
simulation PRNG seeds, the actual number of MC replicates, censoring time
distribution, precise meaning of the `20% / 40%` target, calibration procedure,
optimizer starting points/bounds/tolerances, or numerical settings for frailty
integration and derivatives. Exact equality of the table entries is therefore
not independently demonstrable from the manuscript alone.

We fix a reproducible choice for the missing censoring design:

1. Administrative `C` is exponential and independent of all true gap times,
   covariates and frailties.
2. The target rate is calibrated in an independently seeded 30,000-subject
   pilot to satisfy `Pr(T_3 > C) = 0.20` or `0.40`, where `T_3=G_1+G_2+G_3`.
3. A subject reaches gap 2 only when gap 1 is completed before `C`, and
   reaches gap 3 only after completion of gap 2. The realized counts for
   entered/completed gaps are saved for every replicate.

Different defensible choices about censoring will shift later-gap intercepts,
which the paper already identifies as potentially biased by selection.

## What is created

`run_monte_carlo.py` writes the following into `--out`:

- `replicate_estimates.csv`: one row per simulated dataset, with all 15 point
  estimates, all MT standard errors, optimization flags, and gap-entry counts;
- `appendix_A_results.csv`: 15 rows per setting, with true parameter, bias,
  empirical SD, mean MT SE, 95% coverage, and the number of usable fits;
- `run_metadata.json`: random seed, number of replicates, quadrature order,
  scenario list, and censoring design.

`published_appendix_A.csv` contains **180 reference rows extracted from the
supplied PDF**, not values from code execution. `compare_published.py` merges
the newly computed results with these references, providing numerical
differences column by column. `extract_paper_tables.py` can reconstruct the
reference CSV from the original PDF if Poppler `pdftotext` is available.

The `verification_runs/` directory includes small *actual executed* output
samples with MT; they demonstrate execution and are not MC estimates precise
enough to make research-level claims about bias or coverage.

## Important limitations

Stage 1 is the article's **working likelihood**, not a corrected estimator
for selection into later gap risk sets. Near-zero spatial SDs can make
finite-difference MT Hessians poorly conditioned; inspect `MT_A_condition`,
optimization flags and counts before interpreting coverage. Each scenario
uses independent three-site blocks (n/3 blocks), matching the text.

This implementation reproduces the mathematical structure and generates new
simulation estimates. It does **not** claim that newly generated random draws
must duplicate the historical Monte Carlo numbers in the appendix.
