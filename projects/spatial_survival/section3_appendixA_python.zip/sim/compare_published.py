"""Join newly simulated results with values extracted from Appendix A."""
import argparse
from pathlib import Path
import pandas as pd


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--results",type=Path,default=Path("results/appendix_A_results.csv"))
    p.add_argument("--reference",type=Path,default=Path("published_appendix_A.csv"))
    p.add_argument("--out",type=Path,default=Path("results/comparison_with_paper.csv"))
    a=p.parse_args()
    measured=pd.read_csv(a.results)
    ref=pd.read_csv(a.reference)
    both=measured.merge(ref,on=["setting","n","tau","censor","parameter"],how="left",
                        validate="one_to_one")
    for col,pub in (("bias","published_bias"),("empirical_sd","published_empirical_sd"),
                    ("mean_mt_se","published_mt_se"),("coverage","published_coverage")):
        both[col+"_difference"]=both[col]-both[pub]
    a.out.parent.mkdir(parents=True,exist_ok=True)
    both.to_csv(a.out,index=False)
    print(f"Wrote {len(both)} rows to {a.out}")


if __name__=="__main__":
    main()
