# Reproducing Section 4: black-tailed gull GPS analysis (Python)

This archive reconstructs Section 4 and Table 2 of Yuqing Fan,
*Modelling Multivariate Spatial-Survival Data using D-Vine Copula*, from the
authors' referenced public GPS files.

## Quick start — runs offline from INCLUDED 71-bird derived data

Requires Python 3.10+.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v

# Main log-logistic two-stage fit + Murphy--Topel SE + 3-family AIC comparison:
python run_gull_analysis.py --compare-families --out results/full

# Faster point-estimate check only:
python run_gull_analysis.py --gh-order 7 --qmc 256 --skip-mt \
    --out results/quick
```

The first command reproduces all computations in this reconstruction without
downloading any source data. The 71-row complete-case file is included at
`data/gull_71_complete_cases.csv`, derived directly from the cited GPS records.

## Re-create the 71-bird data from the ORIGINAL GPS records

Data source: Suzuki, S., Mizutani, Y., Yoda, K., Goto, Y. (2026),
*Data and code from: Older gulls adopt more diverse wind drift compensation
strategies*. Dryad. https://doi.org/10.5061/dryad.rr4xgxdqj

The full Dryad deposit is >6 GB because it includes a stored Stan fit;
**that 6-GB file is not needed**. The analysis uses the original GPS input
CSV, available as 11 year-split files in the authors' GitHub repository at
`SerinaSSuzuki/Wind-drift-compensation-analysis`. We pin the commit to
`ad44d2b340c07667d0588841237d2ac3bd734973`.

```bash
# Downloads approximately 99 MB; requires network access:
python download_source.py --out data/raw

# Extract exactly the three positive intervals per earliest eligible bird-year:
python prepare_gull_data.py data/raw/*.csv \
    --out data/gull_71_complete_cases.csv
```

Processing steps:

1. For each `(bird ID=foot, year, trip ID=ID)`, choose the earliest GPS fix.
2. In each bird-year, require at least four distinct foraging trips.
3. Retain only the earliest eligible bird-year per bird; use the earliest four
   trip starts, ordered by actual GPS timestamps.
4. Exclude records without a consistent observed bird age or without three
   **strictly positive** between-trip differences.
5. Transform the differences from UTC timestamps to hours and standardize
   age with the sample SD (`ddof=1`).

The reconstruction from 896,971 raw GPS points produces **71 complete-case
birds**, exactly the sample size reported in Section 4.

Note that recorded trip starts are **proxies** for biological departures.
Between-departure gaps include previous foraging trip durations, and the
original data cannot supply identifiable administrative censoring times.
The real-data analysis is therefore a complete-case illustration, as in the
PDF, not a validation of selection under right censoring.

## Fit specification

- Three AFT models for positive gap times with standardized bird age.
- Gaussian residual copula expressed through partial correlations
  `(rho12, rho23, rho13;2)` (trivariate Gaussian D-vine).
- Spatially correlated independent-by-margin Gaussian frailties with
  `K_ik = exp(-distance_km / 2)`, range fixed at 2 km.
- Birds sorted by **longitude then latitude** and assigned consecutively
  to 24 blocks of 3 (final block of 2). This geographic ordering is an
  explicit reconstruction: the PDF only says “ordered geographically” and
  does not reveal the original block map.
- Margin comparison across `loglogistic`, `lognormal`, and `weibull` families,
  with 15-parameter joint-model AIC including the change of variables from
  log gaps to original positive gaps.

Stage 1 integrates the spatial frailties for each marginal log-time density
using `--gh-order 9` Gauss-Hermite quadrature in up to three dimensions.
Stage 2 uses the exact complete-case likelihood factorization as a product
of integrated marginal spatial likelihoods times an expectation of the
Gaussian copula density under the three independent marginal frailty
posteriors. The latter expectation is approximated with **Sobol posterior
importance sampling**, using 1,024 fixed draws by default. Posterior-centered
Gaussian proposals are computed by Laplace approximation, with importance
weights correcting the proposal. MT scores are differentiated numerically
with common Sobol draws to propagate both stages' estimation uncertainty.
`--gh-order` and `--qmc` can be increased for convergence checks; QMC must be
a power of two.

For a geographic grouping sensitivity analysis, add `--grouping latitude`.
This uses latitude then longitude ordering. Original ordering is unknown.

## Output files

`run_gull_analysis.py` writes into `--out`:

- `table2_estimates.csv`: 15 fitted parameter estimates and cluster MT SEs;
- `table2_vs_paper.csv`: side-by-side estimates and numeric differences from
  `reference_section4.csv` (Table 2 as printed in the manuscript);
- `aic_comparison.csv`: AICs for requested fitted margin families;
- `geographic_blocks.csv`: exact sorting, block memberships, and projected
  coordinates used in the reconstruction;
- `run_metadata.json`: parameterization, integration settings, seed, fit time,
  and MT matrix condition number.

`verified_results/` contains executed **real** log-logistic MT and three-family
AIC outputs from this reconstruction, not invented target values.

## Interpreting numerical discrepancies

Our verified run (`GH=9`, `Sobol=1024`, longitude grouping) yields:

| Quantity | Reconstructed | Paper |
| --- | ---: | ---: |
| Age slope, gap 1 | 0.0707 | 0.0713 |
| Age slope, gap 2 | 0.0832 | 0.0813 |
| Age slope, gap 3 | 0.0531 | 0.0535 |
| Vine rho12 | 0.4596 | 0.4367 |
| Vine rho23 | 0.1915 | 0.1921 |
| Vine rho13;2 | 0.0532 | 0.0489 |
| AIC log-logistic | 2026.62 | 2019.41 |
| AIC lognormal | 2033.58 | 2029.12 |
| AIC Weibull | 2059.60 | 2105.74 |

The winning margin family and most slopes/dependence estimates agree closely.
The AICs and some frailty estimates do not match exactly; the article does not
specify raw code, exact geographical ordering, frailty-integration settings,
or the Weibull parameterization used in the exploratory comparison. We do
**not** tune inputs to force the printed numbers.

The full dataset is publicly cited; the published 71-row subset in this ZIP
is a new derived CSV, not an assertion that this is the author's undisclosed
original analysis file.
