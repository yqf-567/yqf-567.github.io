# Verified Section 4 reconstruction

Verified in Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3.

1. 11 raw GPS CSVs obtained from the study authors' public GitHub files
   (896,971 GPS records); the preprocessing script generated exactly 71 birds
   with the age and three positive gaps required by the PDF.
   SHA-256 of the supplied derived CSV:
   `21c0b9e1703408a67b1e9fe352fecc442ff22003a59500e3815a17cf7639ca7c`.
2. Bird coordinates sorted longitudinally into 24 blocks with at most three
   subjects each; `geographic_blocks.csv` records exact membership.
3. Fitted the log-logistic model, its 15 MT standard errors, and the lognormal
   and Weibull AIC comparisons (`verified_results/`).
4. All 4 unit tests passed.
5. Independent quadrature check (`GH=13`, `Sobol=4096`, with MT skipped):
   log-logistic AIC 2026.80 versus 2026.62 at the default `GH=9`, `Sobol=1024`;
   same winning family. High-order results are not silently substituted for
   the default reproducibility-run values.

Main results:

| Quantity | Reproduction | Manuscript |
| --- | ---: | ---: |
| n birds | 71 | 71 |
| spatial blocks | 24 | 24 |
| log-logistic AIC | 2026.62 | 2019.41 |
| lognormal AIC | 2033.58 | 2029.12 |
| Weibull AIC | 2059.60 | 2105.74 |
| gap 1 age beta (MT SE) | 0.0707 (0.0464) | 0.0713 (0.0460) |
| gap 2 age beta (MT SE) | 0.0832 (0.0842) | 0.0813 (0.0828) |
| gap 3 age beta (MT SE) | 0.0531 (0.0956) | 0.0535 (0.0963) |
| rho12 (MT SE) | 0.4596 (0.1380) | 0.4367 (0.1293) |
| rho23 (MT SE) | 0.1915 (0.1200) | 0.1921 (0.1240) |
| rho13;2 (MT SE) | 0.0532 (0.1694) | 0.0489 (0.1699) |

The differences are **genuine discrepancies**, not numeric targets to be
forced by data manipulation. The original geographic ordering, frailty
integration specifications, and exact Weibull setup are not available in the
manuscript. Changing to geographic *latitude* ordering noticeably changes
some estimates; the PDF's phrase “ordered geographically” is insufficient
to determine uniquely which blocks the authors fitted.
