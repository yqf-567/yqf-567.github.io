"""Download original public GPS CSVs from the authors' pinned GitHub commit.

If raw data already exist, this is optional: data/gull_71_complete_cases.csv
is distributed with this archive. Total original CSV download: ~99 MB.
"""

import argparse
from pathlib import Path
import urllib.request


REPO="SerinaSSuzuki/Wind-drift-compensation-analysis"
COMMIT="ad44d2b340c07667d0588841237d2ac3bd734973"
SIZES={
    "input_GPS2013_1.csv":19359953,
    "input_GPS2013_2.csv":19435138,
    "input_GPS2014.csv":6930149,
    "input_GPS2015.csv":11152777,
    "input_GPS2016.csv":13298612,
    "input_GPS2017.csv":417997,
    "input_GPS2018.csv":990808,
    "input_GPS2019.csv":3662448,
    "input_GPS2020.csv":3170284,
    "input_GPS2021.csv":14755102,
    "input_GPS2022.csv":7954480,
}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--out",type=Path,default=Path("data/raw"))
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    for name,expected in SIZES.items():
        dest=a.out/name
        if dest.is_file() and dest.stat().st_size==expected:
            print("Already exists:",name)
            continue
        url=f"https://raw.githubusercontent.com/{REPO}/{COMMIT}/Input/GPS/input_data/{name}"
        print("Downloading:",name,flush=True)
        with urllib.request.urlopen(url,timeout=90) as source, dest.open("wb") as sink:
            while True:
                chunk=source.read(2**20)
                if not chunk:break
                sink.write(chunk)
        if dest.stat().st_size!=expected:
            raise IOError(f"{name}: expected {expected} bytes; got {dest.stat().st_size}")
    print("All raw GPS files ready in",a.out.resolve())


if __name__=="__main__":main()
