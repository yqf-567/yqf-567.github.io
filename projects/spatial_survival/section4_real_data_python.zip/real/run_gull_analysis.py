"""Section 4 reproduction. Example: python run_gull_analysis.py --help"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from real_model import build_blocks, fit_real, mt_real
from spatial_vine import PARAMETER_NAMES, natural_parameters


def main():
    p = argparse.ArgumentParser(description="Fit the Section 4 black-tailed gull spatial D-vine")
    p.add_argument("--data", type=Path, default=Path("data/gull_71_complete_cases.csv"))
    p.add_argument("--out", type=Path, default=Path("results"))
    p.add_argument("--family", choices=["loglogistic", "lognormal", "weibull"],
                   default="loglogistic")
    p.add_argument("--compare-families", action="store_true", help="fit all 3 margins and compare AIC")
    p.add_argument("--spatial-range-km",type=float,default=2)
    p.add_argument("--grouping", choices=["longitude", "latitude"],default="longitude")
    p.add_argument("--gh-order",type=int,default=9)
    p.add_argument("--qmc",type=int,default=1024, help="power of two >=16")
    p.add_argument("--seed",type=int,default=8642)
    p.add_argument("--maxiter",type=int,default=150)
    p.add_argument("--skip-mt",action="store_true", help="diagnostic: do not calculate MT standard errors")
    a = p.parse_args()
    if not a.data.exists():
        p.error(f"Data not found: {a.data}")
    df = pd.read_csv(a.data)
    blocks, sorted_df = build_blocks(df,a.spatial_range_km,a.grouping)
    if len(df)!=71 or len(blocks)!=24:
        print(f"WARNING: n={len(df)}, blocks={len(blocks)}; paper reports 71 and 24")
    a.out.mkdir(parents=True,exist_ok=True)
    sorted_df.to_csv(a.out/"geographic_blocks.csv",index=False)
    start=time.time()
    families = ["loglogistic","lognormal","weibull"] if a.compare_families else [a.family]
    models={}
    rows=[]
    for fam in families:
        print(f"Fitting {fam} margins ...", flush=True)
        gamma,aic,diagnostics=fit_real(blocks,fam,a.gh_order,a.qmc,a.seed,a.maxiter)
        models[fam]=gamma
        rows.append(dict(family=fam,AIC=float(aic),all_converged=all(d["success"] for d in diagnostics),
                         details=json.dumps(diagnostics)))
        pd.DataFrame(rows).to_csv(a.out/"aic_comparison.csv",index=False)
    main_gamma=models[a.family]
    if a.skip_mt:
        se=np.full(15,np.nan)
        se_diagnostics={"skipped":True}
    else:
        print("Calculating cluster-level Murphy--Topel sandwich ...",flush=True)
        se,se_diagnostics=mt_real(blocks,main_gamma,a.family,a.gh_order,a.qmc,a.seed)
    estimate=natural_parameters(main_gamma)
    estimates=pd.DataFrame({"parameter":PARAMETER_NAMES,"estimate":estimate,"MT_SE":se})
    estimates.to_csv(a.out/"table2_estimates.csv",index=False)
    reference_path=Path(__file__).parent/"reference_section4.csv"
    if reference_path.exists():
        reference=pd.read_csv(reference_path)
        compare=estimates.merge(reference,on="parameter",how="left")
        compare["estimate_difference"]=compare["estimate"]-compare["published_estimate"]
        compare["MT_SE_difference"]=compare["MT_SE"]-compare["published_MT_SE"]
        compare.to_csv(a.out/"table2_vs_paper.csv",index=False)
    meta={"source":"Suzuki et al. 2026; DOI 10.5061/dryad.rr4xgxdqj",
          "n_birds":len(df),"n_blocks":len(blocks),"family":a.family,
          "spatial_range_km":a.spatial_range_km,"grouping":a.grouping,
          "gh_order":a.gh_order,"qmc":a.qmc,"seed":a.seed,
          "qmc_method":"Sobol Gaussian posterior importance sampling, fixed common random numbers",
          "elapsed_seconds":time.time()-start, "standard_errors":se_diagnostics}
    (a.out/"run_metadata.json").write_text(json.dumps(meta,indent=2))
    print(estimates.to_string(index=False,float_format=lambda x:f"{x:.4f}"))
    print(f"Results: {a.out.resolve()}")


if __name__=="__main__":
    main()
