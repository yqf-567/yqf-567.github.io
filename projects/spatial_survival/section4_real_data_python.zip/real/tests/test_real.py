import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

from real_model import (FAMILIES, build_blocks, gh_nodes_weights, log_residual_density,
                        residual_cdf, posterior_basis, block_log_copula_ratio)


class RealTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=pd.read_csv(Path(__file__).resolve().parents[1]/"data/gull_71_complete_cases.csv")

    def test_71_and_24(self):
        self.assertEqual(len(self.data),71)
        blocks,_=build_blocks(self.data)
        self.assertEqual(len(blocks),24)
        self.assertEqual(sum(b.m for b in blocks),71)
        self.assertTrue(np.all(self.data[["gap1_h","gap2_h","gap3_h"]].to_numpy()>0))
        self.assertAlmostEqual(self.data["age_z"].mean(),0,places=12)
        self.assertAlmostEqual(self.data["age_z"].std(ddof=1),1,places=12)

    def test_marginal_cdf_monotone(self):
        z=np.linspace(-3,3,15)
        for fam in FAMILIES:
            self.assertTrue(np.all(np.diff(residual_cdf(z,fam))>0))
            self.assertTrue(np.all(np.isfinite(log_residual_density(z,fam))))

    def test_quadrature_weights(self):
        for m in (1,2,3):
            z, logw=gh_nodes_weights(m,7)
            self.assertEqual(z.shape,(7**m,m))
            self.assertAlmostEqual(np.exp(logw).sum(),1.,places=11)

    def test_posterior_copula_independence(self):
        blocks,_=build_blocks(self.data)
        theta=np.tile([3.6,.07,np.log(.35),np.log(.35)],3)
        b=posterior_basis(blocks[0],theta,"loglogistic",256,2)
        self.assertAlmostEqual(block_log_copula_ratio(b,[0,0,0]),0,places=11)


if __name__=="__main__":unittest.main()
