"""Complete-case three-gap spatial AFT / Gaussian D-vine application.

The real-data section selects log-logistic margins; Gaussian and Weibull
margins are additionally fitted for the reported exploratory AIC comparison.
For non-normal margins, spatial frailties are integrated numerically using
Gauss-Hermite quadrature in stage 1 and *deterministic* Sobol importance
integration of the spatial frailty posterior in stage 2.

This is an explicit numerical reconstruction from the article, not a claim
to reproduce its undisclosed choice of spatial grouping or integration nodes.
"""

from __future__ import annotations

from functools import lru_cache

import numpy as np
import pandas as pd
from numpy.polynomial.hermite import hermgauss
from scipy.linalg import cholesky, cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.special import expit, log_expit, logsumexp, ndtr, ndtri
from scipy.stats import qmc, norm

from spatial_vine import (Block, PARAMETER_NAMES, corr_matrix, natural_parameters,
                          _gradient, _hessian)


FAMILIES = ("loglogistic", "lognormal", "weibull")


def build_blocks(data, spatial_range_km=2.0, grouping="longitude"):
    """Geographic ordering, consecutive groups <=3, local km projection.

    The PDF says 'ordered geographically' but does not provide a sorting key
    or the original block memberships. We choose longitude with latitude
    tie-break. This is *an explicit reconstruction choice* that can change
    estimates and MT scores; group membership is saved in output.
    """
    d = data.copy()
    if grouping == "longitude":
        d = d.sort_values(["longitude", "latitude", "bird_id"])
    elif grouping == "latitude":
        d = d.sort_values(["latitude", "longitude", "bird_id"])
    else:
        raise ValueError("grouping must be longitude or latitude")
    d = d.reset_index(drop=True)
    d["spatial_block"] = d.index // 3 + 1
    mid_lat = np.deg2rad(d["latitude"].mean())
    d["east_km"] = (d["longitude"] - d["longitude"].mean()) * 111.32*np.cos(mid_lat)
    d["north_km"] = (d["latitude"] - d["latitude"].mean()) * 111.195
    blocks = []
    for _, g in d.groupby("spatial_block", sort=True):
        times = g[["gap1_h", "gap2_h", "gap3_h"]].to_numpy(float)
        blocks.append(Block(x=g["age_z"].to_numpy(float),
                            coordinates=g[["east_km", "north_km"]].to_numpy(float),
                            time=times,
                            event=np.ones_like(times, dtype=bool),
                            entered=np.ones_like(times, dtype=bool),
                            spatial_range=spatial_range_km))
    return blocks, d


def log_residual_density(z, family):
    if family == "loglogistic":
        return log_expit(z) + log_expit(-z)
    if family == "lognormal":
        return norm.logpdf(z)
    if family == "weibull":
        return z-np.exp(np.clip(z, -700, 50))
    raise ValueError(f"unknown family {family}")


def residual_cdf(z, family):
    if family == "loglogistic":
        u = expit(z)
    elif family == "lognormal":
        u = ndtr(z)
    elif family == "weibull":
        u = -np.expm1(-np.exp(np.clip(z, -700, 50)))
    else:
        raise ValueError(family)
    return np.clip(u, 1e-10, 1-1e-10)


@lru_cache(maxsize=30)
def gh_nodes_weights(m, order):
    node, weight = hermgauss(order)
    grid = np.array(np.meshgrid(*([np.sqrt(2)*node]*m), indexing="ij"))
    z = grid.reshape(m, -1).T
    wg = np.array(np.meshgrid(*([weight/np.sqrt(np.pi)]*m), indexing="ij"))
    logw = np.log(np.prod(wg.reshape(m, -1), axis=0))
    return z, logw


def margin_loglik(block, theta4, j, family, gh_order=9):
    """Log L1jb with all observed gaps; frailties integrated numerically."""
    a, beta, ls, lt = theta4
    sigma, tau = np.exp(ls), np.exp(lt)
    z, logw = gh_nodes_weights(block.m, gh_order)
    w = tau * (z @ cholesky(block.k, lower=True).T)
    logg = np.log(block.time[:, j])
    resid = (logg[None, :] - (a + beta*block.x)[None, :] - w)/sigma
    ll = (log_residual_density(resid, family) - ls).sum(axis=1)
    return float(logsumexp(logw + ll))  # -sum(log gap) constant omitted


def _initial(blocks, j):
    x = np.concatenate([b.x for b in blocks])
    y = np.concatenate([np.log(b.time[:, j]) for b in blocks])
    design = np.column_stack([np.ones(len(x)), x])
    beta = np.linalg.lstsq(design, y, rcond=None)[0]
    sd = max(.16, np.std(y - design@beta))
    return np.array([beta[0], beta[1], np.log(sd*.65), np.log(sd*.6)])


def fit_margins(blocks, family, gh_order=9, maxiter=150):
    values, details = [], []
    for j in range(3):
        obj = lambda par: -sum(margin_loglik(b, par, j, family, gh_order) for b in blocks)
        opt = minimize(obj, _initial(blocks, j), method="L-BFGS-B",
                       bounds=[(None, None), (None, None),
                               (np.log(.04), np.log(4)),
                               (np.log(.02), np.log(5))],
                       options={"maxiter": maxiter, "ftol": 2e-10})
        values.extend(opt.x)
        details.append({"stage": f"margin{j+1}", "success": bool(opt.success),
                        "nll":float(opt.fun), "message":str(opt.message)})
    return np.array(values), details


def _posterior_laplace(block, theta4, j, family):
    """Local Gaussian importance proposal for spatial frailties w_j | y_j."""
    a, beta, ls, lt = theta4
    sigma, tau = np.exp(ls), np.exp(lt)
    m = block.m
    v = tau*tau*block.k
    prior_inv = np.linalg.inv(v)
    logg = np.log(block.time[:, j])
    mu = a + beta*block.x
    w = np.zeros(m)
    for it in range(40):
        z = np.clip((logg-mu-w)/sigma, -100, 100)
        if family == "lognormal":
            df = -z
            minus_d2f = np.ones(m)
        elif family == "loglogistic":
            u = expit(z)
            df = 1 - 2*u
            minus_d2f = 2*u*(1-u)
        elif family == "weibull":
            ez = np.exp(np.clip(z, -100, 50))
            df = 1 - ez
            minus_d2f = ez
        score = -df/sigma - prior_inv@w
        H = prior_inv + np.diag(minus_d2f/sigma**2)
        step = np.linalg.solve(H, score)
        if np.linalg.norm(step) > 10:
            step *= 10 / np.linalg.norm(step)
        w += step
        if np.max(np.abs(step)) < 1e-9:
            break
    cov = np.linalg.inv(H)
    return w, cov


@lru_cache(maxsize=100)
def sobol_normals(m, n_qmc, seed):
    if n_qmc < 16 or (n_qmc & (n_qmc-1)):
        raise ValueError("QMC samples must be a power of two >= 16")
    sampler = qmc.Sobol(d=3*m, scramble=True, seed=seed)
    return ndtri(np.clip(sampler.random_base2(int(np.log2(n_qmc))), 1e-12, 1-1e-12))


def posterior_basis(block, theta12, family, n_qmc, seed):
    """Fixed posterior-importance weights and Gaussian-copula normal scores.

    For complete cases, full likelihood / product marginal likelihood equals
    E_{product marginal frailty posteriors}[product_i c_D(U_i)]. We use
    posterior-centered normal proposals and self-normalized QMC importance.
    """
    m = block.m
    normal_draws = sobol_normals(m, n_qmc, seed)
    theta = np.asarray(theta12).reshape(3, 4)
    weights = np.zeros(n_qmc)
    z_cop = np.empty((n_qmc, m, 3))
    for j in range(3):
        a, beta, ls, lt = theta[j]
        sigma, tau = np.exp(ls), np.exp(lt)
        mode, proposal_cov = _posterior_laplace(block, theta[j], j, family)
        z = normal_draws[:, j*m:(j+1)*m]
        w = mode + z@cholesky(proposal_cov, lower=True).T
        y = np.log(block.time[:, j])
        resid = (y[None, :] - (a+beta*block.x)[None, :] - w)/sigma
        ll = (log_residual_density(resid, family) - ls).sum(axis=1)
        # Multivariate normal density ratio prior(w)/proposal(w).
        prior_cov = tau*tau*block.k
        prior_fac = cho_factor(prior_cov, lower=True)
        prior_quad = (w * cho_solve(prior_fac, w.T).T).sum(axis=1)
        center = w-mode
        prop_fac = cho_factor(proposal_cov, lower=True)
        prop_quad = (center * cho_solve(prop_fac, center.T).T).sum(axis=1)
        ld_prior = 2*np.log(np.diag(prior_fac[0])).sum()
        ld_prop = 2*np.log(np.diag(prop_fac[0])).sum()
        weights += ll-.5*(prior_quad-prop_quad + ld_prior-ld_prop)
        z_cop[:, :, j] = ndtri(residual_cdf(resid, family))
    weights -= logsumexp(weights)
    return weights, z_cop


def block_log_copula_ratio(basis, eta):
    weight, z = basis
    R = corr_matrix(eta)
    sign, logdet = np.linalg.slogdet(R)
    if sign <= 0:
        return -np.inf
    M = np.linalg.inv(R)-np.eye(3)
    exponent = -.5*np.einsum("sbi,ij,sbj->s", z, M, z)
    exponent -= .5*z.shape[1]*logdet
    return float(logsumexp(weight+exponent))


def fit_vine(blocks, theta12, family, n_qmc=1024, seed=8642, maxiter=150):
    bases = [posterior_basis(b, theta12, family, n_qmc, seed+i)
             for i, b in enumerate(blocks)]
    def obj(rhos):
        return -sum(block_log_copula_ratio(bas, rhos) for bas in bases)
    opt = minimize(obj, [.25,.25,0], method="L-BFGS-B",
                   bounds=[(-.965,.965)]*3, options={"maxiter":maxiter,"ftol":1e-10})
    return np.r_[theta12, opt.x], {"stage":"vine","success":bool(opt.success),
                                     "nll":float(opt.fun),"message":str(opt.message)}, bases


def full_joint_loglik(blocks, gamma, family, gh_order=9, n_qmc=1024, seed=8642,
                      precomputed_bases=None):
    marginal = sum(margin_loglik(b, gamma[4*j:4*j+4], j, family, gh_order)
                   for b in blocks for j in range(3))
    bases = precomputed_bases or [posterior_basis(b, gamma[:12], family, n_qmc, seed+i)
                                  for i,b in enumerate(blocks)]
    ratio = sum(block_log_copula_ratio(bas, gamma[12:]) for bas in bases)
    # The marginal and copula terms above are for log times Y=logG.
    # Translate to original observed gap-time density for AIC.
    jac = sum(np.log(b.time).sum() for b in blocks)
    return float(marginal + ratio - jac)


def fit_real(blocks, family="loglogistic", gh_order=9, n_qmc=1024,
             seed=8642, maxiter=150):
    theta, margin_details = fit_margins(blocks, family, gh_order, maxiter)
    gamma, vine_detail, bases = fit_vine(blocks, theta, family, n_qmc, seed, maxiter)
    ll = full_joint_loglik(blocks, gamma, family, gh_order, n_qmc, seed, bases)
    return gamma, -2*ll+2*len(gamma), margin_details+[vine_detail]


def mt_real(blocks, gamma, family="loglogistic", gh_order=9,
            n_qmc=1024, seed=8642):
    """Cluster MT sandwich for the reconstructed non-Gaussian likelihood.

    Central numerical derivatives propagate stage-1 uncertainty through the
    estimated frailty posterior and the second-stage copula criterion. Normal
    proposals depend on theta; Sobol draws remain fixed (common random numbers).
    """
    psi = np.zeros((len(blocks), 15))
    A = np.zeros((15, 15))
    for ib,b in enumerate(blocks):
        for j in range(3):
            sl = slice(4*j,4*j+4)
            psi[ib,sl] = _gradient(lambda x: margin_loglik(b,x,j,family,gh_order), gamma[sl])
        def copscore(rhos):
            bas=posterior_basis(b,gamma[:12],family,n_qmc,seed+ib)
            return block_log_copula_ratio(bas, rhos)
        psi[ib,12:] = _gradient(copscore, gamma[12:])
    for j in range(3):
        sl = slice(4*j,4*j+4)
        A[sl,sl] = _hessian(lambda x: -sum(margin_loglik(b,x,j,family,gh_order)
                                              for b in blocks), gamma[sl])
    # Compute Hessian of the negative second-stage ratio only in its last
    # three rows; numeric gradient wrt eta of blockwise first-stage scores is 0.
    def nll2(gam):
        return -sum(block_log_copula_ratio(
            posterior_basis(b,gam[:12],family,n_qmc,seed+ib), gam[12:])
            for ib,b in enumerate(blocks))
    step=8e-4*np.maximum(1,np.abs(gamma))
    f0=nll2(gamma)
    for k in range(12,15):
        hk=np.zeros(15);hk[k]=step[k]
        A[k,k]=(nll2(gamma+hk)-2*f0+nll2(gamma-hk))/step[k]**2
        for t in list(range(12))+list(range(12,k)):
            ht=np.zeros(15); ht[t]=step[t]
            A[k,t]=(nll2(gamma+hk+ht)-nll2(gamma+hk-ht)
                    -nll2(gamma-hk+ht)+nll2(gamma-hk-ht))/(4*step[k]*step[t])
            if t>=12: A[t,k]=A[k,t]
    B=psi.T@psi
    inv=np.linalg.pinv(A,rcond=1e-9)
    V=inv@B@inv.T
    V=(V+V.T)/2
    se=np.sqrt(np.maximum(np.diag(V),0))
    for k in (2,3,6,7,10,11):
        se[k]*=np.exp(gamma[k])
    return se, {"condition_number":float(np.linalg.cond(A)),
                 "independent_blocks":len(blocks)}
