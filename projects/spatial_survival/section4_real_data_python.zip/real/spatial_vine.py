"""Spatial Gaussian AFT / trivariate Gaussian D-vine with sequential censoring.

Reproduction of equations (1)--(9) of Fan, *Modelling Multivariate
Spatial-Survival Data using D-Vine Copula*. The Gaussian case admits a
particularly useful exact reduction: integrating all spatial frailties gives
a multivariate Gaussian law for the log-gap times within a spatial block.

The only numerical integration remaining is an at-most-trivariate Gaussian
upper-orthant probability for censored, entered gaps. We use fixed-order
deterministic Gauss-Legendre quadrature (not random multivariate CDF calls),
so finite-difference scores are reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.special import ndtr, ndtri
from scipy.stats import norm


PARAMETER_NAMES = [
    "alpha1", "beta1", "sigma1", "tau1",
    "alpha2", "beta2", "sigma2", "tau2",
    "alpha3", "beta3", "sigma3", "tau3",
    "rho12", "rho23", "rho13_2",
]


@dataclass(frozen=True)
class Block:
    x: np.ndarray                 # shape (m,)
    coordinates: np.ndarray       # (m, 2); arbitrary consistent distance unit
    time: np.ndarray              # (m, 3), entered recorded durations, NaN otherwise
    event: np.ndarray             # (m, 3), completed gap flags
    entered: np.ndarray           # (m, 3), gap risk set membership
    spatial_range: float

    def __post_init__(self):
        m = len(self.x)
        if not (self.coordinates.shape == (m, 2)
                and self.time.shape == self.event.shape == self.entered.shape == (m, 3)):
            raise ValueError("Inconsistent block array dimensions")
        if np.any(self.event & ~self.entered):
            raise ValueError("Events cannot occur before a gap is entered")
        if np.any(self.time[self.entered] <= 0):
            raise ValueError("Entered follow-up durations must be positive")
        if self.spatial_range <= 0:
            raise ValueError("Spatial range must be positive")

    @property
    def k(self):
        d = self.coordinates[:, None, :] - self.coordinates[None, :, :]
        return np.exp(-np.linalg.norm(d, axis=-1) / self.spatial_range)

    @property
    def m(self):
        return self.x.size


def corr_matrix(rhos):
    """Gaussian D-vine partial correlations -> full 3x3 correlation matrix."""
    a, b, c = np.asarray(rhos, dtype=float)
    if np.any(np.abs([a, b, c]) >= 1):
        raise ValueError("All vine partial correlations must have magnitude < 1")
    r13 = a * b + np.sqrt((1 - a*a) * (1 - b*b)) * c
    return np.array([[1.0, a, r13], [a, 1.0, b], [r13, b, 1.0]])


@lru_cache(maxsize=12)
def _quad(n):
    z, w = leggauss(n)
    return (z + 1) * .5, w * .5


def upper_orthant(lower, mu, cov, order=20):
    """P(Y_i > lower_i for every i), Y multivariate normal, dim <= 3.

    One/two dimensional Gaussian conditional probability integration is exact
    up to deterministic Gauss-Legendre quadrature error. Dimension 3 uses two
    nested 1D integrals over conditional Gaussian tail probabilities.
    """
    lower, mu, cov = np.asarray(lower), np.asarray(mu), np.asarray(cov)
    d = len(lower)
    if not d:
        return 1.0
    if d > 3:
        raise ValueError("This implementation assumes <=3 subjects per block")
    if d == 1:
        return float(norm.sf((lower[0] - mu[0]) / np.sqrt(cov[0, 0])))
    nodes, weights = _quad(order)
    v1 = cov[0, 0]
    p1 = norm.sf((lower[0] - mu[0]) / np.sqrt(v1))
    if p1 < 1e-300:
        return 0.0
    x1 = mu[0] + np.sqrt(v1) * norm.isf(np.maximum(p1 * (1-nodes), 1e-300))
    mu2 = mu[1] + cov[1, 0] / v1 * (x1 - mu[0])
    v2 = max(cov[1, 1] - cov[1, 0]**2 / v1, 1e-14)
    p2 = norm.sf((lower[1] - mu2) / np.sqrt(v2))
    if d == 2:
        return float(np.clip(p1 * np.dot(weights, p2), 0, 1))
    # Conditional distribution of Y3 given Y1 and Y2, evaluated at each
    # nested quadrature point. All operations are vectorized.
    z2 = norm.isf(np.maximum(p2[:, None] * (1 - nodes[None, :]), 1e-300))
    x2 = mu2[:, None] + np.sqrt(v2) * z2
    v3_on1 = cov[2, 2] - cov[2, 0]**2 / v1
    c23_on1 = cov[2, 1] - cov[2, 0]*cov[1, 0]/v1
    mu3_on1 = mu[2] + cov[2, 0]/v1 * (x1 - mu[0])
    mu3 = mu3_on1[:, None] + (c23_on1/v2) * (x2 - mu2[:, None])
    v3 = max(v3_on1 - c23_on1**2/v2, 1e-14)
    p3 = norm.sf((lower[2] - mu3) / np.sqrt(v3))
    return float(np.clip(p1 * np.dot(weights * p2, p3 @ weights), 0, 1))


def gaussian_observed_loglik(mu, cov, time, event, entered, order=20):
    """Observed Gaussian *log-time* log-likelihood, omitting fixed Jacobian.

    Unentered gaps are integrated away, not assigned artificial censoring.
    The exact observed log-gap density is Gaussian pdf for completed gaps
    multiplied by P(entered censored log gaps exceed their available times).
    """
    t = np.asarray(time).ravel()
    ev = np.asarray(event).ravel()
    en = np.asarray(entered).ravel()
    idx_e = np.flatnonzero(en & ev)
    idx_c = np.flatnonzero(en & ~ev)
    if not (idx_e.size or idx_c.size):
        return 0.0
    observed = np.log(t[idx_e])
    thresholds = np.log(t[idx_c])
    ll = 0.0
    if idx_e.size:
        delta = observed - mu[idx_e]
        v_ee = cov[np.ix_(idx_e, idx_e)]
        fac, lower = cho_factor(v_ee, lower=True, check_finite=False)
        inv_delta = cho_solve((fac, lower), delta, check_finite=False)
        ll = -.5 * (idx_e.size*np.log(2*np.pi)
                     + 2*np.log(np.diag(fac)).sum() + delta@inv_delta)
    if idx_c.size:
        mu_c = mu[idx_c].copy()
        v_cc = cov[np.ix_(idx_c, idx_c)].copy()
        if idx_e.size:
            v_ce = cov[np.ix_(idx_c, idx_e)]
            mu_c += v_ce @ inv_delta
            v_cc -= v_ce @ cho_solve((fac, lower), v_ce.T, check_finite=False)
        v_cc = (v_cc + v_cc.T)*.5
        p = upper_orthant(thresholds, mu_c, v_cc, order=order)
        ll += np.log(max(p, 1e-300))
    return float(ll)


def block_margin_loglik(block, theta4, j, order=20):
    alpha, beta, log_sigma, log_tau = theta4
    sigma, tau = np.exp(log_sigma), np.exp(log_tau)
    mu = alpha + beta*block.x
    cov = sigma*sigma*np.eye(block.m) + tau*tau*block.k
    return gaussian_observed_loglik(mu, cov, block.time[:, j],
                                    block.event[:, j], block.entered[:, j], order)


def block_joint_loglik(block, gamma, order=20):
    theta = np.asarray(gamma[:12]).reshape(3, 4)
    rhos = gamma[12:]
    R = corr_matrix(rhos)
    m = block.m
    alpha = theta[:, 0]
    beta = theta[:, 1]
    sigma = np.exp(theta[:, 2])
    tau = np.exp(theta[:, 3])
    mu = (alpha[None, :] + block.x[:, None]*beta[None, :]).ravel()
    # sigma residual correlations apply within a subject; spatial random
    # effects apply across subjects separately for each gap.
    c = np.kron(np.eye(m), np.outer(sigma, sigma)*R)
    for j in range(3):
        ix = np.arange(j, 3*m, 3)
        c[np.ix_(ix, ix)] += tau[j]**2*block.k
    return gaussian_observed_loglik(mu, c, block.time,
                                    block.event, block.entered, order)


def natural_parameters(gamma):
    result = np.asarray(gamma, dtype=float).copy()
    for k in (2, 3, 6, 7, 10, 11):
        result[k] = np.exp(result[k])
    return result


def _init_margin(blocks, j):
    xs, ys = [], []
    for b in blocks:
        mask = b.entered[:, j] & b.event[:, j]
        xs.extend(b.x[mask])
        ys.extend(np.log(b.time[mask, j]))
    if len(xs) > 5:
        design = np.column_stack([np.ones(len(xs)), xs])
        a, beta = np.linalg.lstsq(design, ys, rcond=None)[0]
        sigma = max(np.std(np.asarray(ys) - design@np.array([a, beta])), .15)
    else:
        a, beta, sigma = 0., 0., .85
    return np.array([a, beta, np.log(max(.12, sigma*.85)), np.log(.4)])


def fit_two_stage(blocks, order=20, maxiter=160, verbose=False):
    if not blocks:
        raise ValueError("At least one spatial block is required")
    theta_est = []
    details = []
    for j in range(3):
        start = _init_margin(blocks, j)
        def obj(p):
            return -sum(block_margin_loglik(b, p, j, order) for b in blocks)
        r = minimize(obj, start, method="L-BFGS-B",
                     bounds=[(None, None), (None, None),
                             (np.log(.025), np.log(6)),
                             (np.log(.025), np.log(5))],
                     options={"maxiter": maxiter, "ftol": 2e-9})
        theta_est.extend(r.x)
        details.append({"stage": f"margin{j+1}", "success": bool(r.success),
                        "message": str(r.message), "nll": float(r.fun),
                        "iterations": int(r.nit)})
    theta_est = np.array(theta_est)
    def obj_eta(rhos):
        return -sum(block_joint_loglik(b, np.r_[theta_est, rhos], order)
                    for b in blocks)
    result = minimize(obj_eta, np.array([.25, .25, 0.]), method="L-BFGS-B",
                      bounds=[(-.965, .965)]*3,
                      options={"maxiter":maxiter, "ftol":2e-9})
    details.append({"stage": "vine", "success": bool(result.success),
                    "message": str(result.message), "nll": float(result.fun),
                    "iterations": int(result.nit)})
    if verbose:
        for row in details:
            print(row)
    return np.r_[theta_est, result.x], details


def _gradient(f, x, eps=1e-4):
    x = np.asarray(x, float)
    step = eps*np.maximum(1., np.abs(x))
    grad = np.empty(x.size)
    for k in range(x.size):
        h = np.zeros_like(x); h[k] = step[k]
        grad[k] = (f(x+h) - f(x-h)) / (2*step[k])
    return grad


def _hessian(f, x, eps=7e-4):
    x = np.asarray(x, float)
    d = len(x)
    step = eps*np.maximum(1., np.abs(x))
    out = np.empty((d, d))
    f0 = f(x)
    for i in range(d):
        hi = np.zeros_like(x); hi[i] = step[i]
        out[i, i] = (f(x+hi)-2*f0+f(x-hi))/(step[i]**2)
        for j in range(i):
            hj = np.zeros_like(x); hj[j] = step[j]
            val = (f(x+hi+hj)-f(x+hi-hj)-f(x-hi+hj)+f(x-hi-hj))
            out[i, j] = out[j, i] = val/(4*step[i]*step[j])
    return out


def murphy_topel(blocks, gamma, order=20):
    """Cluster-stacked Murphy--Topel covariance in natural parameter units.

    Psi_b=(d log L1,b / d theta, d log p_b / d eta). All derivatives are
    central finite differences of each block's observed likelihood. A is the
    negative summed Jacobian of the stacked scores. The covariance is
    A^-1(sum_b psi_b psi_b')A^-T (no additional /n factor).
    """
    gamma = np.asarray(gamma, float)
    # B: cluster outer products, NOT subject-independent outer products.
    psi = np.empty((len(blocks), 15))
    for ib, b in enumerate(blocks):
        for j in range(3):
            off = 4*j
            psi[ib, off:off+4] = _gradient(
                lambda p: block_margin_loglik(b, p, j, order), gamma[off:off+4])
        psi[ib, 12:] = _gradient(
            lambda p: block_joint_loglik(b, np.r_[gamma[:12], p], order), gamma[12:])
    B = psi.T@psi
    A = np.zeros((15, 15))
    for j in range(3):
        ix = slice(4*j, 4*j+4)
        A[ix, ix] = _hessian(lambda p: -sum(
            block_margin_loglik(b, p, j, order) for b in blocks), gamma[ix])
    # Bottom row-block: derivative of second-stage score wrt all parameters.
    # The fixed L1 denominator in eq (8) has zero derivative wrt eta.
    def second_stage_neg(full):
        return -sum(block_joint_loglik(b, full, order) for b in blocks)
    # Hessian blocks eta/theta and eta/eta (omits unused theta/theta).
    steps = 6e-4 * np.maximum(1, np.abs(gamma))
    f0 = second_stage_neg(gamma)
    for k in range(12, 15):
        hk = np.zeros(15); hk[k] = steps[k]
        A[k, k] = (second_stage_neg(gamma+hk)-2*f0+second_stage_neg(gamma-hk))/steps[k]**2
        for t in list(range(12)) + list(range(12, k)):
            ht = np.zeros(15); ht[t] = steps[t]
            val = (second_stage_neg(gamma+hk+ht)
                   -second_stage_neg(gamma+hk-ht)
                   -second_stage_neg(gamma-hk+ht)
                   +second_stage_neg(gamma-hk-ht))/(4*steps[k]*steps[t])
            A[k, t] = val
            if t >= 12:
                A[t, k] = val
    Ainv = np.linalg.pinv(A, rcond=1e-9)
    cov = Ainv@B@Ainv.T
    cov = .5*(cov+cov.T)
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    for k in (2, 3, 6, 7, 10, 11):
        se[k] *= np.exp(gamma[k])  # delta method from log SD to SD
    return se, cov, {"A_condition": float(np.linalg.cond(A)),
                     "cluster_count": len(blocks), "scores": psi}
