"""Rebuild three inter-departure times from Suzuki et al. (2026) GPS files.

Source: https://doi.org/10.5061/dryad.rr4xgxdqj
Files: input_data.csv OR the 11 original year-split input_GPS*.csv files in
https://github.com/SerinaSSuzuki/Wind-drift-compensation-analysis/tree/main/Input/GPS/input_data

Raw points are not redistributed in the reproduction archive; the 71-row
derived complete-case dataset is distributed with citation/provenance.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


NEEDED = ["time", "foot", "year", "ID", "age", "lon", "lat"]


def build(raw_paths):
    data = pd.concat([pd.read_csv(p, usecols=NEEDED) for p in raw_paths],
                     ignore_index=True)
    data["time"] = pd.to_datetime(data["time"], utc=True, errors="coerce")
    data["year"] = pd.to_numeric(data["year"], errors="coerce")
    for c in ("age", "lat", "lon"):
        data[c] = pd.to_numeric(data[c], errors="coerce")
    data = data.dropna(subset=["time", "foot", "year", "ID", "lat", "lon"])
    data = data.sort_values(["foot", "year", "time", "ID"], kind="mergesort")
    # First GPS fix is a trip-start *proxy*, not a verified departure time.
    starts = (data.groupby(["foot", "year", "ID"], sort=False, as_index=False)
                   .agg(start=("time", "first"), age=("age", "first"),
                        longitude=("lon", "first"), latitude=("lat", "first")))
    starts = starts.sort_values(["foot", "year", "start", "ID"])
    # A bird-year qualifies if at least four distinct trip identifiers exist.
    counts = starts.groupby(["foot", "year"]).size().rename("trip_count")
    eligible = counts[counts >= 4].reset_index()[["foot", "year"]]
    starts = starts.merge(eligible, on=["foot", "year"], how="inner")
    # Earliest eligible bird-year, avoiding repeated birds across calendar years.
    year1 = starts.groupby("foot")["year"].transform("min")
    starts = starts.loc[starts["year"].eq(year1)].copy()
    starts["ord"] = starts.groupby("foot").cumcount()
    starts = starts.loc[starts["ord"] < 4].copy()
    valid = starts.groupby("foot").filter(lambda x: len(x) == 4 and
                         x["age"].notna().all() and x["age"].nunique() == 1)
    # Grouping and timestamps, rather than numeric Trip_ID ordering, determine
    # the four earliest trips. Strictly positive gap durations are mandatory.
    rows = []
    for foot, g in valid.groupby("foot", sort=True):
        g = g.sort_values(["start", "ID"])
        t = g["start"].to_numpy(dtype="datetime64[ns]")
        gap = np.diff(t).astype("timedelta64[s]").astype(float)/3600
        if np.any(gap <= 0):
            continue
        rows.append(dict(bird_id=str(foot), year=int(g["year"].iloc[0]),
                         age=float(g["age"].iloc[0]),
                         longitude=float(g["longitude"].iloc[0]),
                         latitude=float(g["latitude"].iloc[0]),
                         gap1_h=float(gap[0]), gap2_h=float(gap[1]),
                         gap3_h=float(gap[2]),
                         start1=g["start"].iloc[0].isoformat(),
                         start2=g["start"].iloc[1].isoformat(),
                         start3=g["start"].iloc[2].isoformat(),
                         start4=g["start"].iloc[3].isoformat()))
    result = pd.DataFrame(rows).sort_values("bird_id").reset_index(drop=True)
    if not result.empty:
        sd = result["age"].std(ddof=1)
        if sd <= 0:
            raise ValueError("Age has zero sample standard deviation")
        result["age_z"] = (result["age"] - result["age"].mean())/sd
    return result


def main():
    p = argparse.ArgumentParser(description="Convert individual GPS fixes to 3 gaps per bird")
    p.add_argument("paths", nargs="+", type=Path, help="input_data.csv or the year-split GPS CSVs")
    p.add_argument("--out", type=Path, default=Path("data/gull_71_complete_cases.csv"))
    a = p.parse_args()
    missing = [str(path) for path in a.paths if not path.is_file()]
    if missing:
        p.error(f"Input file(s) missing: {missing}")
    result = build(a.paths)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(a.out, index=False)
    print("Birds:", len(result))
    print("Wrote:", a.out.resolve())
    if len(result) != 71:
        print("NOTE: paper reports 71 birds. Different source/version or filtering criteria may apply.")


if __name__ == "__main__":
    main()
