#!/usr/bin/env python3
"""Pre-registered-style synthetic stress test of shift and conformal coverage on WDBC.

Data: UCI WDBC, bundled by scikit-learn; no other source or external validation claimed.
Test outcomes select engineered prevalence mixtures and evaluate outcomes only.
No test outcomes used for preprocessing/adaptation/calibration/model fitting.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import bootstrap
from sklearn import __version__ as sklearn_version
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, brier_score_loss
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ALPHA = .10
PREVALENCES = (.2, .4, .7)
SHIFT_TYPES = ('none', 'orthogonal', 'discriminative', 'mixed', 'case_noise')
ADAPTATIONS = ('none', 'center_all', 'preserve_axis')
MODEL_NAMES = ('logistic', 'forest', 'histboost')


def cp_quantile(scores, alpha=ALPHA):
    scores = np.asarray(scores)
    assert len(scores)>0
    k = int(np.ceil((len(scores)+1)*(1-alpha)))
    return float(np.sort(scores)[k-1]) if k<=len(scores) else float('inf')


def calibration_quantiles(prob, y, alpha=ALPHA):
    s = np.where(y==1, 1-prob, prob)
    return {'marginal': np.repeat(cp_quantile(s,alpha),2),
            'classwise': np.array([cp_quantile(s[y==0],alpha), cp_quantile(s[y==1],alpha)])}


def prediction_set_metrics(prob, y, q):
    probs = np.column_stack((1-prob,prob))
    membership = (1-probs)<=q[None,:]
    hits = membership[np.arange(len(y)),y]
    sizes = membership.sum(axis=1)
    out = {'coverage':float(hits.mean()),'mean_size':float(sizes.mean()),
           'singleton':float((sizes==1).mean()),'empty':float((sizes==0).mean())}
    for label,word in [(0,'benign'),(1,'malignant')]:
        out['coverage_'+word]=float(hits[y==label].mean()) if np.any(y==label) else np.nan
    return out


def signed_ece(prob,y,bins=10):
    inds=np.minimum(np.floor(prob*bins).astype(int),bins-1)
    return float(sum((inds==j).mean()*abs(y[inds==j].mean()-prob[inds==j].mean()) for j in range(bins) if np.any(inds==j)))


def summarize_score(prob,y):
    cls=prob>=0.5
    return dict(auc=float(roc_auc_score(y,prob)),
        balanced_accuracy=float(balanced_accuracy_score(y,cls)),
        sensitivity=float(cls[y==1].mean()),
        specificity=float((~cls[y==0]).mean()),
        brier=float(brier_score_loss(y,prob)), ece=float(signed_ece(prob,y)))


def fit_model(name, x,y,seed):
    if name=='logistic': model=LogisticRegression(C=1.,max_iter=2500)
    elif name=='forest': model=RandomForestClassifier(n_estimators=120,min_samples_leaf=2,
              max_features='sqrt', random_state=seed, n_jobs=1)
    elif name=='histboost': model=HistGradientBoostingClassifier(max_iter=120,max_leaf_nodes=9,
              learning_rate=.05,l2_regularization=1.,random_state=seed)
    else: raise ValueError(name)
    model.fit(x,y)
    return model


def direction_from_train(z,y):
    delta=z[y==1].mean(axis=0)-z[y==0].mean(axis=0)
    norm=np.linalg.norm(delta)
    if norm<1.e-12: raise ValueError('degenerate class-mean axis')
    return delta/norm


def project_perp(v,u):
    """Remove component parallel to a unit-norm discriminative axis."""
    return v-np.dot(v,u)*u


def adapt(x,reference,u,method):
    drift=x.mean(axis=0)-reference
    if method=='none': return x.copy()
    if method=='center_all': return x-drift
    if method=='preserve_axis': return x-project_perp(drift,u)
    raise ValueError(method)


def sample_population(ids,y,pi,n,rng):
    n1=int(round(n*pi)); n0=n-n1
    pos=ids[y[ids]==1]; neg=ids[y[ids]==0]
    if min(len(pos)-n1,len(neg)-n0)<0: raise ValueError('not enough test cases')
    out=np.r_[rng.choice(pos,n1,replace=False),rng.choice(neg,n0,replace=False)]
    return rng.permutation(out)


def make_shift(x, kind, u, rng, strength=.75):
    p=x.shape[1]
    if kind=='none': return x.copy()
    if kind=='case_noise': return x+.50*rng.standard_normal(x.shape)
    vec=rng.standard_normal(p)
    if kind=='orthogonal': vec=project_perp(vec,u)
    elif kind=='discriminative': vec=np.sign(vec@u)*u
    elif kind=='mixed': pass
    else:raise ValueError(kind)
    vec=vec/max(np.linalg.norm(vec),1e-10)*np.sqrt(p)*strength
    return x+vec[None,:]


def ci_from_split_means(vals, seed=2026):
    a=np.array(vals,dtype=float)
    if len(a)<2:return (float(a.mean()),np.nan,np.nan)
    rng=np.random.default_rng(seed)
    draws=a[rng.integers(0,len(a),(4000,len(a)))].mean(axis=1)
    return float(a.mean()),float(np.quantile(draws,.025)),float(np.quantile(draws,.975))


def one_seed(X,y,seed,test_size=60,alpha=ALPHA):
    train,rem=train_test_split(np.arange(len(y)),train_size=.60,random_state=seed,stratify=y)
    cal,test=train_test_split(rem,train_size=.50,random_state=10000+seed,stratify=y[rem])
    assert not (set(train)&set(cal) or set(train)&set(test) or set(cal)&set(test))
    scale=StandardScaler().fit(X[train]); z=scale.transform(X)
    u=direction_from_train(z[train],y[train])
    reference=z[cal].mean(axis=0)
    rng=np.random.default_rng(900000+seed)
    # Draw scenarios once per seed and reuse across classifiers.
    cases={}
    for pi in PREVALENCES:
        target=sample_population(test,y,pi,test_size,rng)
        for kind in SHIFT_TYPES:
            cases[(pi,kind)]=(target,make_shift(z[target],kind,u,rng))
    models={name:fit_model(name,z[train],y[train],seed) for name in MODEL_NAMES}
    rows=[]
    for name,model in models.items():
        cal_prob=model.predict_proba(z[cal])[:,1]
        quantiles=calibration_quantiles(cal_prob,y[cal],alpha)
        for (pi,kind),(target,xshift) in cases.items():
            yy=y[target]
            for approach in ADAPTATIONS:
                xadj=adapt(xshift,reference,u,approach)
                pred=model.predict_proba(xadj)[:,1]
                standard=summarize_score(pred,yy)
                for cp_name,q in quantiles.items():
                    row={'seed':seed,'model':name,'prevalence':pi,'shift':kind,
                         'adaptation':approach,'cp':cp_name,'n_target':len(yy),
                         'malignant':int(yy.sum()),'n_train':len(train),'n_cal':len(cal),
                         'n_test_pool':len(test), 'shift_strength':.75,
                         'target_size':test_size}
                    row.update(standard)
                    row.update(prediction_set_metrics(pred,yy,q))
                    rows.append(row)
    return rows


def summarize(df):
    keys=['model','prevalence','shift','adaptation','cp']
    metric_cols=['auc','balanced_accuracy','sensitivity','specificity','brier','ece',
                 'coverage','coverage_malignant','coverage_benign','mean_size','singleton','empty']
    rng=np.random.default_rng(20261022)
    summary=[]
    for k,g in df.groupby(keys,sort=True):
        row=dict(zip(keys,k));row['repeats']=len(g)
        for col in metric_cols:
            a=g[col].to_numpy()
            boot=a[rng.integers(0,len(a),size=(1200,len(a)))].mean(axis=1)
            row[col]=float(a.mean());row[col+'_mc_low']=float(np.quantile(boot,.025));row[col+'_mc_high']=float(np.quantile(boot,.975))
        summary.append(row)
    return pd.DataFrame(summary)


def paired(df):
    # Paired differences between projected and full centering on identical patient batches.
    key=['seed','model','prevalence','shift','cp']
    left=df[df.adaptation=='preserve_axis'].set_index(key)
    right=df[df.adaptation=='center_all'].set_index(key)
    out=[]
    for k,row in left.iterrows():
        base=right.loc[k]
        d=dict(zip(key,k))
        for m in ('coverage','coverage_malignant','balanced_accuracy','brier','mean_size'):
            d[m+'_axis_minus_full']=float(row[m]-base[m])
        out.append(d)
    return pd.DataFrame(out)


def figures(summary,output):
    out=output/'figures';out.mkdir(exist_ok=True)
    for model in MODEL_NAMES:
        dat=summary[(summary.model==model)&(summary.cp=='classwise')]
        fig, axs=plt.subplots(1,2,figsize=(10.7,4.3),layout='constrained')
        conditions=['none','orthogonal','mixed']
        labels={'none':'No drift','orthogonal':'Nuisance offset','mixed':'Mixed offset'}
        for ax, prev in zip(axs,(.2,.7)):
            for condition,marker in zip(conditions,['o','s','^']):
                sub=dat[(dat.prevalence==prev)&(dat['shift']==condition)]
                for approach,ls in [('none',':'),('center_all','--'),('preserve_axis','-')]:
                    g=sub[sub.adaptation==approach]
                    # Provide 3 experimental arms; x ordinal categoric shift values
                    x=conditions.index(condition)+{'none':-.13,'center_all':0,'preserve_axis':.13}[approach]
                    ax.errorbar([x],[g.coverage_malignant.iloc[0]],
                        yerr=[[g.coverage_malignant.iloc[0]-g.coverage_malignant_mc_low.iloc[0]],
                              [g.coverage_malignant_mc_high.iloc[0]-g.coverage_malignant.iloc[0]]],
                        marker=marker,linestyle='none',capsize=2,
                        label=approach if condition=='none' else None)
            ax.set_xticks([0,1,2],[labels[x] for x in conditions],rotation=17)
            ax.axhline(.9,color='gray',linestyle=':')
            ax.set_ylim(0,1.04);ax.set_title(f'Target malignant prevalence {prev:.0%}')
            ax.set_ylabel('Malignant class-conditional coverage')
        axs[0].legend(loc='lower left',fontsize=8)
        fig.savefig(out/f'{model}_coverage.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.8),layout='constrained')
    sub=summary[(summary.model=='logistic')&(summary.cp=='marginal')&(summary['shift']=='none')]
    for a,marker in [('none','o'),('center_all','s'),('preserve_axis','^')]:
        g=sub[sub.adaptation==a].sort_values('prevalence')
        ax.plot(g.prevalence,g.balanced_accuracy,'-'+marker,label=a)
    ax.set(xlabel='Malignant prevalence of constructed test batch',ylabel='Balanced accuracy',ylim=(.65,1.01))
    ax.legend();fig.savefig(out/'prevalence_only_balacc.png',dpi=180);plt.close(fig)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=Path('.'))
    p.add_argument('--seeds',type=int,default=60)
    p.add_argument('--target-size',type=int,default=60)
    p.add_argument('--start',type=int,default=0)
    p.add_argument('--partial',action='store_true')
    args=p.parse_args()
    root=args.out.resolve(); (root/'results').mkdir(parents=True,exist_ok=True)
    (root/'figures').mkdir(exist_ok=True)
    raw=load_breast_cancer()
    X=np.array(raw.data,dtype=np.float64)
    y=(raw.target==0).astype(int)
    assert X.shape==(569,30) and int(y.sum())==212
    fingerprint=hashlib.sha256(np.ascontiguousarray(X).tobytes()+y.tobytes()).hexdigest()
    data=[]
    for seed in range(args.start,args.seeds):
        data.extend(one_seed(X,y,seed,args.target_size))
        if (seed+1)%10==0: print('Completed',seed+1,'of',args.seeds,flush=True)
    df=pd.DataFrame(data)
    if args.partial:
        df.to_csv(root/'results'/f'partial_{args.start:03d}_{args.seeds:03d}.csv',index=False)
        return
    df.to_csv(root/'results'/'all_experiments.csv',index=False,float_format='%.10g')
    group=summarize(df);group.to_csv(root/'results'/'summary.csv',index=False,float_format='%.9g')
    contrasts=paired(df);contrasts.to_csv(root/'results'/'paired_differences.csv',index=False,float_format='%.9g')
    figures(group,root)
    meta={'dataset':'UCI Wisconsin Diagnostic Breast Cancer, sklearn bundled data',
       'sha256_X_float64_plus_y_int64':fingerprint,'n':len(y),'p':X.shape[1],
       'positives':int(y.sum()),'seeds':args.seeds,'test_batch':args.target_size,
       'alpha':ALPHA,'prevalences':PREVALENCES,'shift_types':SHIFT_TYPES,
       'adaptations':ADAPTATIONS,'model_names':MODEL_NAMES,
       'random_split':'seed 0..seeds-1: 60/20/20 stratified; holdout subsample 60',
       'confidence_interval':'Monte Carlo repeat-level descriptive bootstrap; NOT patient CI',
       'python':platform.python_version(),'sklearn':sklearn_version,'numpy':np.__version__,
       'pandas':pd.__version__}
    (root/'results'/'metadata.json').write_text(json.dumps(meta,indent=2))
    # Print manuscript values from summary: no hand-authored data.
    sl=group[(group.model=='logistic')&(group.cp=='classwise')&
             (group['shift'].isin(['none','orthogonal','mixed','discriminative']))]
    print(sl[['prevalence','shift','adaptation','coverage_malignant','balanced_accuracy','mean_size']].to_string(index=False))

if __name__=='__main__':main()
