#!/usr/bin/env python3
"""Readable publication figures from saved, fully reproducible summary table."""
from pathlib import Path
import argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

LABELS={'none':'No adaptation','center_all':'Full centering','preserve_axis':'Axis-preserving'}
KINDS={'none':'No technical shift','orthogonal':'Nuisance-axis shift','mixed':'Mixed shift',
       'discriminative':'Disease-axis shift','case_noise':'Patient-wise noise'}

def build(root):
    df=pd.read_csv(root/'results'/'summary.csv')
    figs=root/'figures'; figs.mkdir(exist_ok=True)
    # Figure 1: pure prior shift confounds adaptation, three models
    fig,axes=plt.subplots(1,3,figsize=(11.8,3.75),sharex=True,sharey=True,layout='constrained')
    for ax,m in zip(axes,['logistic','forest','histboost']):
        z=df[(df.model==m)&(df.cp=='classwise')&(df['shift']=='none')]
        for adapt,style in [('none','o-'),('center_all','s--'),('preserve_axis','^-')]:
            a=z[z.adaptation==adapt].sort_values('prevalence')
            ax.plot(a.prevalence,a.coverage_malignant,style,lw=1.7,ms=5,
                    label=LABELS[adapt])
        ax.axhline(.9,color='gray',linestyle=':',linewidth=1.0)
        ax.set_title({'logistic':'Logistic regression','forest':'Random forest','histboost':'Gradient boosting'}[m])
        ax.set_xticks([.2,.4,.7],['20%','40%','70%']);ax.set_ylim(.45,1.035);ax.grid(alpha=.16)
        ax.set_xlabel('Target malignant-case fraction')
    axes[0].set_ylabel('Malignant-label conformal coverage')
    axes[0].legend(fontsize=8,loc='lower left')
    fig.savefig(figs/'fig1_prevalence_confounds.png',dpi=220,bbox_inches='tight'); plt.close(fig)

    # Figure 2: discriminatory-axis failure visible; 70% malignancy target
    fig,axes=plt.subplots(1,2,figsize=(11.1,4.1),sharey=True,layout='constrained')
    scenarios=['none','orthogonal','mixed','discriminative','case_noise']
    approaches=['none','center_all','preserve_axis']
    xpos=np.arange(len(scenarios))
    for ax,m in zip(axes,['logistic','forest']):
        z=df[(df.model==m)&(df.cp=='classwise')&(df.prevalence==.7)]
        for ix,app in enumerate(approaches):
            vals=[];lo=[];hi=[]
            for s in scenarios:
                r=z[(z['shift']==s)&(z.adaptation==app)].iloc[0]
                vals.append(r.coverage_malignant)
                lo.append(r.coverage_malignant-r.coverage_malignant_mc_low)
                hi.append(r.coverage_malignant_mc_high-r.coverage_malignant)
            ax.bar(xpos+(ix-1)*.25,vals,.23,label=LABELS[app],alpha=.85)
            ax.errorbar(xpos+(ix-1)*.25,vals,yerr=[lo,hi],linestyle='none',capsize=2,color='black',elinewidth=.6)
        ax.set_xticks(xpos,['No shift','Nuisance','Mixed','Disease axis','Noise'],rotation=24)
        ax.set_title({'logistic':'Logistic regression','forest':'Random forest'}[m])
        ax.axhline(.9,color='gray',linestyle=':',linewidth=1.1)
        ax.set_ylim(0,1.04);ax.grid(axis='y',alpha=.15)
    axes[0].set_ylabel('Malignant-label conformal coverage')
    axes[0].legend(fontsize=8,loc='lower left')
    fig.savefig(figs/'fig2_shift_mechanisms.png',dpi=220,bbox_inches='tight');plt.close(fig)

    # Figure 3: AUC can remain high while coverage varies
    fig,ax=plt.subplots(figsize=(7.5,4.4),layout='constrained')
    z=df[(df.model=='logistic')&(df.cp=='classwise')&(df.prevalence==.7)]
    for app,marker in [('none','o'),('center_all','s'),('preserve_axis','^')]:
        t=z[z.adaptation==app]
        ax.scatter(t.auc,t.coverage_malignant,marker=marker,s=56,label=LABELS[app])
    ax.axhline(.9,color='gray',linestyle=':')
    ax.set(xlabel='AUROC across target batches',ylabel='Malignant-label conformal coverage',xlim=(.975,1.003),ylim=(0,1.02))
    ax.legend(loc='lower left');ax.grid(alpha=.16)
    fig.savefig(figs/'fig3_auc_vs_coverage.png',dpi=220,bbox_inches='tight');plt.close(fig)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',default='.',type=Path);a=p.parse_args();build(a.out.resolve())
