#!/usr/bin/env python3
"""Aggregate prespecified independent RNG repetitions (overlapping people between repeats)."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import sklearn
import scipy
import platform
from sklearn.datasets import load_breast_cancer
import hashlib
from study import summarize,paired,figures,ALPHA,PREVALENCES,SHIFT_TYPES,ADAPTATIONS,MODEL_NAMES


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='.',type=Path);args=p.parse_args()
    root=args.out.resolve()
    chunks=sorted((root/'results').glob('partial_*.csv'))
    if not chunks: raise RuntimeError('No partial CSVs found')
    df=pd.concat([pd.read_csv(c) for c in chunks],ignore_index=True)
    seed_values=sorted(df.seed.unique());assert seed_values==list(range(len(seed_values))),seed_values
    count_expected=len(MODEL_NAMES)*len(PREVALENCES)*len(SHIFT_TYPES)*len(ADAPTATIONS)*2
    counts=df.groupby('seed').size()
    assert (counts==count_expected).all(),counts
    assert df.shape[0]==len(seed_values)*count_expected
    df.to_csv(root/'results'/'all_experiments.csv',index=False,float_format='%.10g')
    out=summarize(df);out.to_csv(root/'results'/'summary.csv',index=False,float_format='%.9g')
    comps=paired(df);comps.to_csv(root/'results'/'paired_differences.csv',index=False,float_format='%.9g')
    figures(out,root)
    x=load_breast_cancer(); xx=np.array(x.data,dtype=np.float64);y=(x.target==0).astype(int)
    metadata={'seeds':len(seed_values),'seed_range':[int(min(seed_values)),int(max(seed_values))],
         'dataset':'Breast Cancer Wisconsin (Diagnostic), UCI 17, sklearn bundled',
         'n_data':len(y),'features':xx.shape[1],'malignant':int(y.sum()),
         'data_sha256':hashlib.sha256(np.ascontiguousarray(xx).tobytes()+y.tobytes()).hexdigest(),
         'target_batch_n':int(df.n_target.iloc[0]),
         'sample_design':'60/20/20 train/cal/test stratified patient subset each seed, 60 target patients per prevalence',
         'nominal_cp':ALPHA,'prevalences':PREVALENCES,'shifts':SHIFT_TYPES,'adaptations':ADAPTATIONS,
         'models':MODEL_NAMES,
         'uncertainty':'resampled repetitions Monte Carlo descriptive intervals; do not interpret as independent sample CI',
         'Python':platform.python_version(),'sklearn':sklearn.__version__,
         'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__}
    (root/'results'/'metadata.json').write_text(json.dumps(metadata,indent=2))
    def look(model,pi,shift,cp='classwise',metric='coverage_malignant'):
        s=out[(out.model==model)&(out.prevalence==pi)&(out['shift']==shift)&(out.cp==cp)]
        return ', '.join(f'{r.adaptation}={getattr(r,metric):.3f} [{getattr(r,metric+"_mc_low"):.3f},{getattr(r,metric+"_mc_high"):.3f}]' for r in s.itertuples())
    for m in MODEL_NAMES:
        print('\n',m)
        for pi in (.2,.7):
            for sh in ['none','orthogonal','mixed','discriminative']:
                print(pi,sh,look(m,pi,sh))
    s=out[(out.model=='logistic')&(out.cp=='marginal')&(out['shift']=='none')]
    print('\nLogistic no-shift balanced accuracy')
    print(s[['prevalence','adaptation','balanced_accuracy']].to_string(index=False))

if __name__=='__main__':main()
