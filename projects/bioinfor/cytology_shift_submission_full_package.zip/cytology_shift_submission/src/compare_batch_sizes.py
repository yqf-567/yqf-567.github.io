#!/usr/bin/env python3
"""Summarize 20-seed paired batch-size sensitivity (n=30 vs n=60)."""
from pathlib import Path
import argparse
import pandas as pd

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default='.');o=p.parse_args().out.resolve()
 d60=pd.read_csv(o/'results/all_experiments.csv');d60=d60[d60.seed<20]
 d30=pd.read_csv(o/'supplement/batch30/results/all_experiments.csv')
 rows=[]
 for n,d in [(30,d30),(60,d60)]:
  z=d[(d.cp=='classwise')&(d['shift']=='orthogonal')]
  for (model,pi,ad),g in z.groupby(['model','prevalence','adaptation']):
   rows.append({'batch_size':n,'model':model,'malignancy_frac':pi,'adaptation':ad,
       'malignant_coverage':float(g.coverage_malignant.mean()),
       'benign_coverage':float(g.coverage_benign.mean()),
       'balanced_accuracy':float(g.balanced_accuracy.mean()),'repeats':len(g)})
 dest=o/'supplement/batch_size_sensitivity.csv';pd.DataFrame(rows).to_csv(dest,index=False,float_format='%.8f')
 print('Created',dest)
if __name__=='__main__':main()
