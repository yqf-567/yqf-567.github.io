# Breast cytology shift — full research and submission-draft package

**Working manuscript:** *When case mix masquerades as batch drift: Prevalence-aware limits of unsupervised centering in breast cytology prediction*

**Status:** Completed research manuscript and executable, tested benchmark; **not** a clinically validated model, evidence of external transportability, or a guaranteed Q2–Q3 journal acceptance. The only primary dataset is the historical Wisconsin Diagnostic Breast Cancer (WDBC) benchmark. Manuscript authorship, journal-specific files, funding/COI declarations and an external cohort remain outstanding.

## Central research question

Can unlabeled feature-mean alignment mistake a change in malignant-case prevalence for a technical batch effect? Our experiments compare no centering, unconstrained centering, and a class-direction-preserving centering negative control. The central mathematical identity is

`target_mean - source_mean = additive_batch_offset + (target_prevalence - source_prevalence) * (malignant_mean - benign_mean)`

The projection protects the prevalence-induced mean component, but cannot correct a true technical offset parallel to the disease direction. It does not provide a general coverage guarantee. The figures and manuscript explicitly show both success and failure.

## Completed evidence

- 569 public de-identified WDBC cases, 30 features (212 malignant, 357 benign), no patient ID used in modeling.
- 60 seeded, overlapping 60/20/20 train/calibration/test splits; 60-case artificial test batches of 20%, 40%, or 70% malignant cases.
- Three fixed classifiers (logistic regression, random forest, histogram gradient boosting), five synthetic stressors, three adaptation strategies, and marginal/classwise split conformal (nominal 90%); 16,200 evaluation rows.
- **Primary contrast:** 70%-malignant batches **with no technical shift**: classwise malignant coverage for logistic regression was 90.7% (none), 62.3% (full centering), 90.8% (axis-preserving); the paired difference axis-preserving minus full was 28.5 percentage points (descriptive repeat-level 95% Monte Carlo interval: 26.8–30.2). The effect replicated with both tree classifiers.
- Designed negative control: a technical offset along the disease direction is **not** corrected by projection. Independent patient-level Gaussian noise is also not generally removable.
- Secondary batch-size study: 20 corresponding seeds comparing 30-case and 60-case target batch sizes; see `supplement/batch_size_sensitivity.csv`.
- Nine unit/integration tests passed. All code, outputs, metadata, model settings and figures supplied.

## Package map

| Path | Purpose |
|---|---|
| `paper.tex` | Editable 10-page manuscript, references through `references.bib` |
| `paper.pdf` | Rendered, visually inspected manuscript |
| `references.bib` | Research bibliography |
| `CITATION_AUDIT.md` | Cross-check links and metadata conflicts for every citation |
| `src/study.py` | Main model-fitting, synthetic shifts, adaptation and conformal evaluation |
| `src/summarize.py` | Recombine saved 10-seed chunks and compute summary statistics |
| `src/plots.py` | Recreate three main publication figures |
| `src/compare_batch_sizes.py` | Summarize target batch n=30 versus n=60 |
| `tests/test_study.py` | Nine tests (equations, invariance, prediction sets, determinism) |
| `results/all_experiments.csv` | 16,200 scenario-level rows, full factorial results |
| `results/summary.csv` | 270 summary conditions with descriptive Monte Carlo uncertainty |
| `results/paired_differences.csv` | Paired projected-versus-full differences |
| `results/metadata.json` | Versions, seeds and WDBC data checksum |
| `results/partial_*.csv` | Six exact ten-seed checkpoints for reproducibility |
| `supplement/batch30/` | Sensitivity outputs for smaller test batches |
| `figures/fig*.png` | Publication-ready 220-DPI figures |
| `SUBMISSION_CHECKLIST.md` | Transparent editorial readiness assessment |
| `MANIFEST_SHA256.txt` | File-integrity checksums |

## Reproduce in Python

Python 3.13 was used with the exact versions in `requirements.txt`.

```bash
python -m pip install -r requirements.txt
python -m pytest tests -q

# Recompute all 60 repeats directly (independent of saved CSVs):
python src/study.py --out . --seeds 60
python src/plots.py --out .
```

**Resource-friendly alternative:** To regenerate summary outputs from the original ten-seed checkpoints, simply run:

```bash
python src/summarize.py --out .
python src/plots.py --out .
```

To regenerate the lower-batch-size sensitivity study:

```bash
python src/study.py --out supplement/batch30 --start 0 --seeds 10 --target-size 30 --partial
python src/study.py --out supplement/batch30 --start 10 --seeds 20 --target-size 30 --partial
python src/summarize.py --out supplement/batch30
python src/compare_batch_sizes.py --out .
```

To compile, a standard TeX installation with BibTeX should support:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```

In this environment `bibtex8` was installed instead of `bibtex`; a wrapper was used during compilation. `paper.bbl` is also included as a compiled bibliography. The included PDF has 10 pages.

## Dataset provenance / ethical scope

UCI Wisconsin Diagnostic Breast Cancer, ID 17, DOI https://doi.org/10.24432/C5DW2B. The numerical feature data are shipped in scikit-learn, and this package does not redistribute the underlying raw patient matrix. Research use of the public de-identified dataset is described; no hospital/site validation or medical diagnostic approval is implied.

## Interpretation and important limitations

1. No independent hospital cohort; all partitions reuse one historical cohort. Repetition-level intervals measure split and perturbation variability only.
2. The perturbations have *not* been measured in real scanning or acquisition batches; clinical error models may differ sharply.
3. Label-shift batches are engineered using test labels **only to create the experimental case mix**. Those labels are not supplied to adjustment algorithms.
4. The axis-preserving transform is a restricted geometric control, not an identifiable correction for arbitrary offsets or a new universal conformal validity proof.
5. Real journal submission requires a named, accountable author team, declared contributions/conflicts, ethics status where applicable, and choosing a target journal with appropriate article type. Q2/Q3 eligibility cannot be inferred solely from formatting or experiment count.

Citation audit was manually cross-referenced to authoritative pages in October 2026. It records a PMLR/DBLP discrepancy in the Lipton et al. ICML page numbers (PMLR is used) and openly notes that the recent 2026 PMLR work has two official publisher representations, not two independent publishers.
