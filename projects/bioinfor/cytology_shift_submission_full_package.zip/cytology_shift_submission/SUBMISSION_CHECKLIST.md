# Pre-submission readiness — transparent assessment

## Completed

- [x] Clear research question and derivation, with explicit identifiability trade-off.
- [x] Fully executable Python code, exact seeds and package versions.
- [x] Public dataset provenance and SHA-256 fingerprint.
- [x] Three predictive models, two conformal variants, five controlled shifts and three prevalence levels.
- [x] Paired comparisons, class-specific endpoints and failure analyses.
- [x] Additional target batch-size sensitivity analysis.
- [x] Reconstructed outputs, publication figures, 10-page rendered manuscript.
- [x] Nine passing automated tests and bibliography metadata audit.
- [x] Caveats on correlated repeats, synthetic shifts, no independent patient CI and lack of clinical applicability.

## Required before an actual journal submission

- [ ] Name accountable authors and verify all results and interpretation independently.
- [ ] Identify a **specific journal**, article type and actual year-dependent quartile; update target formatting.
- [ ] Add authorship, affiliations, funding, conflicts, ethics/regulatory and AI-use declarations as appropriate.
- [ ] Decide whether journal permits one-cohort simulation/methodological studies; a clinical-method article will likely require an independent cohort.
- [ ] Ideally replicate in independently collected data with acquisition/batch metadata, and benchmark against relevant domain adaptation/calibration baselines.
- [ ] Perform a full, documented novelty/similarity review (this package contains a focused literature audit, not a systematic review).
- [ ] Publish code in a permanent public repository / archival DOI if required.

**Assessment:** This is a complete *submission-format computational methods draft* and reproducible study. It is **not** a clinical validation paper, and there is no defensible guarantee of acceptance at a Q2–Q3 journal without editorial fit and stronger external evidence.
