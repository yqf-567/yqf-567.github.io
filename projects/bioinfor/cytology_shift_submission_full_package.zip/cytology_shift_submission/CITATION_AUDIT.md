# Citation integrity audit — 22 October 2026

All 11 bibliography records were checked for existence, title, author, year, and available volume/page or DOI against at least two records or independently identifiable official resources. *Metadata verification does not establish exhaustive literature coverage or prove novelty.*

| Bib key | Primary verification | Independent cross-check | Audit result |
| --- | --- | --- | --- |
| `uciWDBC1993` | UCI official dataset page, DOI 10.24432/C5DW2B: https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic | scikit-learn dataset documentation: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html | UCI original data attributed; distribution confirmed |
| `wolberg1994` | Publisher: https://www.sciencedirect.com/science/article/pii/030438359490099X | PubMed PMID 8168063: https://pubmed.ncbi.nlm.nih.gov/8168063/ | Title, three authors, Cancer Letters 77:163–171, DOI |
| `angelopoulos2023` | Publisher/now Publishers PDF summary: https://www.nowpublishers.com/article/DownloadSummary/MAL-101 | DBLP: https://dblp.org/rec/journals/ftml/AngelopoulosB23.html | DOI 10.1561/2200000101; vol.16(4):494–591 |
| `tibshirani2019` | NeurIPS proceedings: https://proceedings.neurips.cc/paper_files/paper/2019/hash/8fb21ee7a2207526da55a679f0332de2-Abstract.html | ML Anthology: https://mlanthology.org/neurips/2019/tibshirani2019neurips-conformal/ | Title and author sequence, vol. 32, pp.2530–2540 |
| `lipton2018` | PMLR: https://proceedings.mlr.press/v80/lipton18a.html | DBLP: https://dblp.org/rec/conf/icml/LiptonWS18.html | Title/authors/year verified. **Index discrepancy:** DBLP lists pp.3128–3136; the official PMLR record lists pp.3122–3130, used here. |
| `romano2020` | NeurIPS: https://proceedings.neurips.cc/paper_files/paper/2020/hash/244edd7e85dc81602b7615cd705545f5-Abstract.html | arXiv: https://arxiv.org/abs/2006.02544 | Title and authors verified; no DOI assumed |
| `johnson2007` | PubMed PMID 16632515: https://pubmed.ncbi.nlm.nih.gov/16632515/ | DOI landing/publisher: https://doi.org/10.1093/biostatistics/kxj037 | Year, title, volume 8(1), 118–127, DOI |
| `collins2024` | BMJ: https://www.bmj.com/content/385/bmj-2023-078378 | PubMed PMID 38626948: https://pubmed.ncbi.nlm.nih.gov/38626948/ | Title, doi, BMJ 385:e078378, published 2024; correction noted on BMJ page |
| `varoquaux2018` | PubMed PMID 28655633: https://pubmed.ncbi.nlm.nih.gov/28655633/ | DOI landing/publisher: https://doi.org/10.1016/j.neuroimage.2017.06.061 | Year 2018 volume 180; DOI 2017 early online, not conflict |
| `boman2026` | PMLR publication: https://proceedings.mlr.press/v329/boman26a.html | PMLR hosted article PDF: https://raw.githubusercontent.com/mlresearch/v329/main/assets/boman26a/boman26a.pdf | 2026 conference publication, PMLR 329:1099–1102. Both resources are from the same publisher; not independent. |
| `pedregosa2011` | JMLR journal: https://www.jmlr.org/papers/v12/pedregosa11a.html | scikit-learn publication page: https://scikit-learn.org/stable/about.html#citing-scikit-learn | Verified JMLR 12:2825–2830, 2011 |

**Scope notes.** This is a bibliography metadata audit, not a systematic review or proof that the proposed axis-preserving correction is unprecedented. The UCI dataset has historical sampling limitations and is not a modern external validation sample. The Boman record has two official representations rather than two independent publishers. No unverified DOI has been inserted.
