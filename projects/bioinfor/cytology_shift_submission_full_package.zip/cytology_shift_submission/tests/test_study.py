import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))

import numpy as np
from sklearn.linear_model import LogisticRegression
from study import (cp_quantile,calibration_quantiles,prediction_set_metrics,
                   direction_from_train,project_perp,adapt,make_shift,
                   sample_population,one_seed)
from sklearn.datasets import load_breast_cancer


def test_finite_sample_quantile():
    assert cp_quantile(np.arange(8.),.10)==float('inf')
    assert cp_quantile(np.arange(19.),.10)==17.


def test_projection_removes_only_orthogonal_shift():
    u=np.array([3.,4.,0.])/5
    v=np.array([2.,-1.,3.])
    p=project_perp(v,u)
    assert abs(np.dot(p,u))<1e-12
    assert np.allclose(v,p+(v@u)*u)


def test_centroid_adjustment_preserves_discriminative_direction():
    ref=np.array([0.,0.]);u=np.array([1.,0.])
    x=np.array([[2.,5.],[4.,7.]])
    y=adapt(x,ref,u,'preserve_axis')
    assert np.allclose(y[:,0],x[:,0])
    assert abs(y[:,1].mean())<1e-12
    assert np.allclose(adapt(x,ref,u,'center_all').mean(axis=0),np.zeros(2))


def test_mixture_mean_identifiability():
    rng=np.random.default_rng(12)
    d=np.array([3.,2.]); mu0=np.array([1.,-1.]);b=np.array([0.3,-0.6])
    pis,pit=.2,.7
    ref=(1-pis)*mu0+pis*(mu0+d)
    tar=(1-pit)*(mu0+b)+pit*(mu0+d+b)
    assert np.allclose(tar-ref,b+(pit-pis)*d)
    assert np.allclose(project_perp(tar-ref,d/np.linalg.norm(d)),project_perp(b,d/np.linalg.norm(d)))


def test_label_free_uses_only_x_and_training_direction():
    rng=np.random.default_rng(3);x=rng.normal(size=(20,4));u=np.array([1.,0.,0.,0.])
    shifted=x+np.array([0,2,-1,0.])
    assert np.allclose(adapt(shifted,x.mean(axis=0),u,'preserve_axis'),x)


def test_shift_types_mechanistic():
    rng=np.random.default_rng(3)
    x=np.zeros((6,5)); u=np.array([1.,0,0,0,0])
    a=make_shift(x,'orthogonal',u,rng)
    assert np.allclose(a[:,0],0)
    assert np.allclose(a[0],a[1])
    b=make_shift(x,'discriminative',u,rng)
    assert np.allclose(b[:,1:],0)


def test_cp_coverage_contains_truth():
    prob=np.array([.1,.9,.1,.9]);y=np.array([0,1,0,1]);q=np.array([.2,.2])
    met=prediction_set_metrics(prob,y,q)
    assert met['coverage']==1.0
    assert met['mean_size']==1.0
    assert met['coverage_malignant']==1.0


def test_logistic_common_shift_auc_invariance():
    rng=np.random.default_rng(5)
    x=rng.normal(size=(90,5));y=(2*x[:,0]+x[:,1]>0).astype(int)
    model=LogisticRegression().fit(x,y)
    a=model.predict_proba(x)[:,1]
    b=model.predict_proba(x+rng.normal(size=5)[None,:])[:,1]
    ix=np.argsort(a);jx=np.argsort(b)
    assert np.array_equal(ix,jx)


def test_complete_seed_reproducible():
    ds=load_breast_cancer();X=ds.data;y=(ds.target==0).astype(int)
    a=one_seed(X,y,0,test_size=60)
    b=one_seed(X,y,0,test_size=60)
    assert len(a)==270
    for r,s in zip(a,b):
        for metric in ['auc','coverage','coverage_malignant','balanced_accuracy']:
            assert np.allclose(r[metric],s[metric])
